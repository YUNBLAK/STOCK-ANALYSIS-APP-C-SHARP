﻿namespace XCI
{
    partial class Main
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series11 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series12 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series13 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.panel_up = new System.Windows.Forms.Panel();
            this.worldtime = new System.Windows.Forms.Label();
            this.panel_logo = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.logoBox = new System.Windows.Forms.PictureBox();
            this.panel_home = new System.Windows.Forms.Panel();
            this.panel_test = new System.Windows.Forms.Panel();
            this.panel_detailView = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel33 = new System.Windows.Forms.Panel();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel58 = new System.Windows.Forms.Panel();
            this.panel67 = new System.Windows.Forms.Panel();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel_chart1under = new System.Windows.Forms.Panel();
            this.panel86 = new System.Windows.Forms.Panel();
            this.panel87 = new System.Windows.Forms.Panel();
            this.panel88 = new System.Windows.Forms.Panel();
            this.chrt1md4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel89 = new System.Windows.Forms.Panel();
            this.chrt1md1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel90 = new System.Windows.Forms.Panel();
            this.chrt1md2 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel91 = new System.Windows.Forms.Panel();
            this.chrt1md3 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel92 = new System.Windows.Forms.Panel();
            this.panel93 = new System.Windows.Forms.Panel();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel94 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.panel95 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.panel96 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.panel97 = new System.Windows.Forms.Panel();
            this.panel98 = new System.Windows.Forms.Panel();
            this.ch4_ltime = new System.Windows.Forms.Label();
            this.panel99 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.panel102 = new System.Windows.Forms.Panel();
            this.panel103 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.panel104 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.panel105 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.panel106 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.panel107 = new System.Windows.Forms.Panel();
            this.panel108 = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.panel109 = new System.Windows.Forms.Panel();
            this.label43 = new System.Windows.Forms.Label();
            this.panel110 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.panel111 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.panel64 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel70 = new System.Windows.Forms.Panel();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel66 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.pnlbtn_CA_03 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.pnlbtn_CA_04 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel112 = new System.Windows.Forms.Panel();
            this.label48 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.panel61 = new System.Windows.Forms.Panel();
            this.panel68 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel_chart2under = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel80 = new System.Windows.Forms.Panel();
            this.panel81 = new System.Windows.Forms.Panel();
            this.OnYearBtn04 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel82 = new System.Windows.Forms.Panel();
            this.OnYearBtn01 = new System.Windows.Forms.Label();
            this.btn_chart2_y05 = new System.Windows.Forms.PictureBox();
            this.panel84 = new System.Windows.Forms.Panel();
            this.OnYearBtn02 = new System.Windows.Forms.Label();
            this.btn_chart2_y06 = new System.Windows.Forms.PictureBox();
            this.panel83 = new System.Windows.Forms.Panel();
            this.OnYearBtn03 = new System.Windows.Forms.Label();
            this.btn_chart2_y07 = new System.Windows.Forms.PictureBox();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.OnBtn04 = new System.Windows.Forms.Label();
            this.btn_chart2_y04 = new System.Windows.Forms.PictureBox();
            this.panel77 = new System.Windows.Forms.Panel();
            this.OnBtn01 = new System.Windows.Forms.Label();
            this.btn_chart2_y01 = new System.Windows.Forms.PictureBox();
            this.panel79 = new System.Windows.Forms.Panel();
            this.OnBtn03 = new System.Windows.Forms.Label();
            this.btn_chart2_y03 = new System.Windows.Forms.PictureBox();
            this.panel78 = new System.Windows.Forms.Panel();
            this.OnBtn02 = new System.Windows.Forms.Label();
            this.btn_chart2_y02 = new System.Windows.Forms.PictureBox();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.lbmin_lp = new System.Windows.Forms.Label();
            this.panel73 = new System.Windows.Forms.Panel();
            this.lbmin_op = new System.Windows.Forms.Label();
            this.panel75 = new System.Windows.Forms.Panel();
            this.lbmin_cp = new System.Windows.Forms.Label();
            this.panel74 = new System.Windows.Forms.Panel();
            this.lbmin_hp = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.lbmax_lp = new System.Windows.Forms.Label();
            this.panel72 = new System.Windows.Forms.Panel();
            this.lbmax_op = new System.Windows.Forms.Label();
            this.panel47 = new System.Windows.Forms.Panel();
            this.lbmax_hp = new System.Windows.Forms.Label();
            this.panel71 = new System.Windows.Forms.Panel();
            this.lbmax_cp = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.label24 = new System.Windows.Forms.Label();
            this.panel43 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel42 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel41 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel63 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.panel65 = new System.Windows.Forms.Panel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel85 = new System.Windows.Forms.Panel();
            this.btn_chart2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel_tmp2 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel_tmp1 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.panel_prediction = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel_tracking = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.panel_list = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel_stock = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.panel_overview = new System.Windows.Forms.Panel();
            this.label50 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label46 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel_searchbox = new System.Windows.Forms.Panel();
            this.tb_searchbox = new System.Windows.Forms.TextBox();
            this.panel_search = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel_stckName = new System.Windows.Forms.Panel();
            this.lb_stockName = new System.Windows.Forms.Label();
            this.panel_upStockName = new System.Windows.Forms.Panel();
            this.lb_upstockName = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel_side = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.btbase9 = new System.Windows.Forms.Panel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panel48 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.btbase8 = new System.Windows.Forms.Panel();
            this.lablsidebnt08 = new System.Windows.Forms.Label();
            this.sidebnt08 = new System.Windows.Forms.PictureBox();
            this.clablsidebnt08 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.btbase7 = new System.Windows.Forms.Panel();
            this.lablsidebnt07 = new System.Windows.Forms.Label();
            this.sidebnt07 = new System.Windows.Forms.PictureBox();
            this.clablsidebnt07 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.btbase6 = new System.Windows.Forms.Panel();
            this.lablsidebnt06 = new System.Windows.Forms.Label();
            this.sidebnt06 = new System.Windows.Forms.PictureBox();
            this.clablsidebnt06 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.btbase5 = new System.Windows.Forms.Panel();
            this.lablsidebnt05 = new System.Windows.Forms.Label();
            this.sidebnt05 = new System.Windows.Forms.PictureBox();
            this.clablsidebnt05 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.btbase4 = new System.Windows.Forms.Panel();
            this.lablsidebnt04 = new System.Windows.Forms.Label();
            this.sidebnt04 = new System.Windows.Forms.PictureBox();
            this.clablsidebnt04 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.btbase3 = new System.Windows.Forms.Panel();
            this.lablsidebnt03 = new System.Windows.Forms.Label();
            this.sidebnt03 = new System.Windows.Forms.PictureBox();
            this.clablsidebnt03 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.btbase2 = new System.Windows.Forms.Panel();
            this.lablsidebnt02 = new System.Windows.Forms.Label();
            this.sidebnt02 = new System.Windows.Forms.PictureBox();
            this.clablsidebnt02 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.btbase1 = new System.Windows.Forms.Panel();
            this.lablsidebnt01 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.sidebnt01 = new System.Windows.Forms.PictureBox();
            this.clablsidebnt01 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.regiontime = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.widepanel = new System.Windows.Forms.Panel();
            this.chart4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel_up.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoBox)).BeginInit();
            this.panel_home.SuspendLayout();
            this.panel_test.SuspendLayout();
            this.panel_detailView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel33.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel58.SuspendLayout();
            this.panel67.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panel_chart1under.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel87.SuspendLayout();
            this.panel88.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel89.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel90.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel91.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel92.SuspendLayout();
            this.panel93.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel94.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel95.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.panel96.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.panel97.SuspendLayout();
            this.panel98.SuspendLayout();
            this.panel99.SuspendLayout();
            this.panel102.SuspendLayout();
            this.panel103.SuspendLayout();
            this.panel104.SuspendLayout();
            this.panel105.SuspendLayout();
            this.panel106.SuspendLayout();
            this.panel107.SuspendLayout();
            this.panel108.SuspendLayout();
            this.panel109.SuspendLayout();
            this.panel110.SuspendLayout();
            this.panel111.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel60.SuspendLayout();
            this.panel70.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.panel49.SuspendLayout();
            this.pnlbtn_CA_03.SuspendLayout();
            this.pnlbtn_CA_04.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel112.SuspendLayout();
            this.panel34.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.panel61.SuspendLayout();
            this.panel68.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.panel_chart2under.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel80.SuspendLayout();
            this.panel81.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel82.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y05)).BeginInit();
            this.panel84.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y06)).BeginInit();
            this.panel83.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y07)).BeginInit();
            this.panel45.SuspendLayout();
            this.panel76.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y04)).BeginInit();
            this.panel77.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y01)).BeginInit();
            this.panel79.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y03)).BeginInit();
            this.panel78.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y02)).BeginInit();
            this.panel40.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel73.SuspendLayout();
            this.panel75.SuspendLayout();
            this.panel74.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel72.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel71.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel62.SuspendLayout();
            this.panel59.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel_tmp2.SuspendLayout();
            this.panel_tmp1.SuspendLayout();
            this.panel_prediction.SuspendLayout();
            this.panel_tracking.SuspendLayout();
            this.panel_list.SuspendLayout();
            this.panel_stock.SuspendLayout();
            this.panel_overview.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel_searchbox.SuspendLayout();
            this.panel_search.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel_stckName.SuspendLayout();
            this.panel_upStockName.SuspendLayout();
            this.panel_side.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel55.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel52.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.panel32.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.btbase9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.btbase8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt08)).BeginInit();
            this.btbase7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt07)).BeginInit();
            this.btbase6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt06)).BeginInit();
            this.btbase5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt05)).BeginInit();
            this.btbase4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt04)).BeginInit();
            this.btbase3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt03)).BeginInit();
            this.btbase2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt02)).BeginInit();
            this.btbase1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt01)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.widepanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_up
            // 
            this.panel_up.Controls.Add(this.worldtime);
            this.panel_up.Controls.Add(this.panel_logo);
            this.panel_up.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_up.Location = new System.Drawing.Point(5, 40);
            this.panel_up.Name = "panel_up";
            this.panel_up.Size = new System.Drawing.Size(1285, 33);
            this.panel_up.TabIndex = 0;
            // 
            // worldtime
            // 
            this.worldtime.AutoSize = true;
            this.worldtime.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.worldtime.ForeColor = System.Drawing.Color.White;
            this.worldtime.Location = new System.Drawing.Point(247, 13);
            this.worldtime.Name = "worldtime";
            this.worldtime.Size = new System.Drawing.Size(8, 12);
            this.worldtime.TabIndex = 15;
            this.worldtime.Text = "-";
            this.worldtime.Visible = false;
            // 
            // panel_logo
            // 
            this.panel_logo.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_logo.Location = new System.Drawing.Point(0, 0);
            this.panel_logo.Name = "panel_logo";
            this.panel_logo.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.panel_logo.Size = new System.Drawing.Size(236, 33);
            this.panel_logo.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(28, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "D A N I E L  A N A L Y T I C S";
            // 
            // logoBox
            // 
            this.logoBox.Image = ((System.Drawing.Image)(resources.GetObject("logoBox.Image")));
            this.logoBox.Location = new System.Drawing.Point(5, 3);
            this.logoBox.Name = "logoBox";
            this.logoBox.Size = new System.Drawing.Size(20, 20);
            this.logoBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logoBox.TabIndex = 0;
            this.logoBox.TabStop = false;
            // 
            // panel_home
            // 
            this.panel_home.Controls.Add(this.panel_test);
            this.panel_home.Controls.Add(this.panel29);
            this.panel_home.Controls.Add(this.panel28);
            this.panel_home.Controls.Add(this.panel26);
            this.panel_home.Controls.Add(this.panel18);
            this.panel_home.Controls.Add(this.panel1);
            this.panel_home.Controls.Add(this.panel_side);
            this.panel_home.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_home.Location = new System.Drawing.Point(5, 73);
            this.panel_home.Name = "panel_home";
            this.panel_home.Size = new System.Drawing.Size(1285, 717);
            this.panel_home.TabIndex = 1;
            // 
            // panel_test
            // 
            this.panel_test.Controls.Add(this.panel_detailView);
            this.panel_test.Controls.Add(this.panel_tmp2);
            this.panel_test.Controls.Add(this.panel_tmp1);
            this.panel_test.Controls.Add(this.panel_prediction);
            this.panel_test.Controls.Add(this.panel_tracking);
            this.panel_test.Controls.Add(this.panel_list);
            this.panel_test.Controls.Add(this.panel_stock);
            this.panel_test.Controls.Add(this.panel_overview);
            this.panel_test.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_test.Location = new System.Drawing.Point(262, 31);
            this.panel_test.Name = "panel_test";
            this.panel_test.Size = new System.Drawing.Size(1023, 625);
            this.panel_test.TabIndex = 9;
            // 
            // panel_detailView
            // 
            this.panel_detailView.Controls.Add(this.splitContainer1);
            this.panel_detailView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_detailView.Location = new System.Drawing.Point(0, 0);
            this.panel_detailView.Name = "panel_detailView";
            this.panel_detailView.Size = new System.Drawing.Size(1023, 625);
            this.panel_detailView.TabIndex = 6;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel33);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel34);
            this.splitContainer1.Size = new System.Drawing.Size(1023, 625);
            this.splitContainer1.SplitterDistance = 510;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 0;
            this.splitContainer1.TabStop = false;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.splitContainer2);
            this.panel33.Controls.Add(this.panel35);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(510, 625);
            this.panel33.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.IsSplitterFixed = true;
            this.splitContainer2.Location = new System.Drawing.Point(0, 19);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.panel38);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.panel39);
            this.splitContainer2.Size = new System.Drawing.Size(510, 606);
            this.splitContainer2.SplitterDistance = 295;
            this.splitContainer2.TabIndex = 1;
            this.splitContainer2.TabStop = false;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.panel58);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel38.Location = new System.Drawing.Point(0, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(510, 295);
            this.panel38.TabIndex = 0;
            // 
            // panel58
            // 
            this.panel58.Controls.Add(this.panel67);
            this.panel58.Controls.Add(this.panel64);
            this.panel58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel58.Location = new System.Drawing.Point(0, 0);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(510, 295);
            this.panel58.TabIndex = 0;
            // 
            // panel67
            // 
            this.panel67.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel67.BackgroundImage")));
            this.panel67.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel67.Controls.Add(this.chart1);
            this.panel67.Controls.Add(this.panel_chart1under);
            this.panel67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel67.Location = new System.Drawing.Point(0, 3);
            this.panel67.Name = "panel67";
            this.panel67.Padding = new System.Windows.Forms.Padding(3);
            this.panel67.Size = new System.Drawing.Size(510, 292);
            this.panel67.TabIndex = 1;
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.Color.Transparent;
            this.chart1.BorderlineColor = System.Drawing.Color.Black;
            this.chart1.BorderSkin.PageColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.AxisY.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.BackColor = System.Drawing.Color.White;
            chartArea1.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea1.BorderColor = System.Drawing.Color.Transparent;
            chartArea1.BorderWidth = 0;
            chartArea1.InnerPlotPosition.Auto = false;
            chartArea1.InnerPlotPosition.Height = 100F;
            chartArea1.InnerPlotPosition.Width = 100F;
            chartArea1.Name = "ChartArea1";
            chartArea1.Position.Auto = false;
            chartArea1.Position.Height = 100F;
            chartArea1.Position.Width = 100F;
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart1.Location = new System.Drawing.Point(3, 3);
            this.chart1.Margin = new System.Windows.Forms.Padding(0);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series1.ChartArea = "ChartArea1";
            series1.LabelForeColor = System.Drawing.Color.Transparent;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.YValuesPerPoint = 4;
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(504, 172);
            this.chart1.TabIndex = 2;
            this.chart1.Text = "chart2";
            // 
            // panel_chart1under
            // 
            this.panel_chart1under.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.panel_chart1under.Controls.Add(this.panel86);
            this.panel_chart1under.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_chart1under.Location = new System.Drawing.Point(3, 175);
            this.panel_chart1under.Name = "panel_chart1under";
            this.panel_chart1under.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.panel_chart1under.Size = new System.Drawing.Size(504, 114);
            this.panel_chart1under.TabIndex = 2;
            // 
            // panel86
            // 
            this.panel86.Controls.Add(this.panel87);
            this.panel86.Controls.Add(this.panel92);
            this.panel86.Controls.Add(this.panel97);
            this.panel86.Controls.Add(this.panel102);
            this.panel86.Controls.Add(this.panel107);
            this.panel86.Location = new System.Drawing.Point(0, 0);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(502, 120);
            this.panel86.TabIndex = 0;
            // 
            // panel87
            // 
            this.panel87.Controls.Add(this.panel88);
            this.panel87.Controls.Add(this.panel89);
            this.panel87.Controls.Add(this.panel90);
            this.panel87.Controls.Add(this.panel91);
            this.panel87.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel87.Location = new System.Drawing.Point(0, 88);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(502, 22);
            this.panel87.TabIndex = 4;
            // 
            // panel88
            // 
            this.panel88.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel88.Controls.Add(this.chrt1md4);
            this.panel88.Controls.Add(this.pictureBox2);
            this.panel88.Location = new System.Drawing.Point(377, 2);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(124, 17);
            this.panel88.TabIndex = 19;
            // 
            // chrt1md4
            // 
            this.chrt1md4.AutoSize = true;
            this.chrt1md4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chrt1md4.ForeColor = System.Drawing.Color.Silver;
            this.chrt1md4.Location = new System.Drawing.Point(3, 0);
            this.chrt1md4.Name = "chrt1md4";
            this.chrt1md4.Size = new System.Drawing.Size(11, 14);
            this.chrt1md4.TabIndex = 10;
            this.chrt1md4.Text = "-";
            this.chrt1md4.Click += new System.EventHandler(this.chrt1md4_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(122, 15);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // panel89
            // 
            this.panel89.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel89.Controls.Add(this.chrt1md1);
            this.panel89.Controls.Add(this.pictureBox3);
            this.panel89.Location = new System.Drawing.Point(1, 2);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(120, 17);
            this.panel89.TabIndex = 16;
            // 
            // chrt1md1
            // 
            this.chrt1md1.AutoSize = true;
            this.chrt1md1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chrt1md1.ForeColor = System.Drawing.Color.Lime;
            this.chrt1md1.Location = new System.Drawing.Point(3, 0);
            this.chrt1md1.Name = "chrt1md1";
            this.chrt1md1.Size = new System.Drawing.Size(24, 14);
            this.chrt1md1.TabIndex = 4;
            this.chrt1md1.Text = "Bar";
            this.chrt1md1.Click += new System.EventHandler(this.chrt1md1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Location = new System.Drawing.Point(0, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(118, 15);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // panel90
            // 
            this.panel90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel90.Controls.Add(this.chrt1md2);
            this.panel90.Controls.Add(this.pictureBox4);
            this.panel90.Location = new System.Drawing.Point(126, 2);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(120, 17);
            this.panel90.TabIndex = 17;
            // 
            // chrt1md2
            // 
            this.chrt1md2.AutoSize = true;
            this.chrt1md2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chrt1md2.ForeColor = System.Drawing.Color.Silver;
            this.chrt1md2.Location = new System.Drawing.Point(3, 0);
            this.chrt1md2.Name = "chrt1md2";
            this.chrt1md2.Size = new System.Drawing.Size(27, 14);
            this.chrt1md2.TabIndex = 8;
            this.chrt1md2.Text = "Line";
            this.chrt1md2.Click += new System.EventHandler(this.chrt1md2_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox4.Location = new System.Drawing.Point(0, 0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(118, 15);
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // panel91
            // 
            this.panel91.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel91.Controls.Add(this.chrt1md3);
            this.panel91.Controls.Add(this.pictureBox5);
            this.panel91.Location = new System.Drawing.Point(252, 2);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(120, 17);
            this.panel91.TabIndex = 18;
            // 
            // chrt1md3
            // 
            this.chrt1md3.AutoSize = true;
            this.chrt1md3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chrt1md3.ForeColor = System.Drawing.Color.Silver;
            this.chrt1md3.Location = new System.Drawing.Point(3, 0);
            this.chrt1md3.Name = "chrt1md3";
            this.chrt1md3.Size = new System.Drawing.Size(40, 14);
            this.chrt1md3.TabIndex = 9;
            this.chrt1md3.Text = "Candle";
            this.chrt1md3.Click += new System.EventHandler(this.chrt1md3_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox5.Location = new System.Drawing.Point(0, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(118, 15);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // panel92
            // 
            this.panel92.Controls.Add(this.panel93);
            this.panel92.Controls.Add(this.panel94);
            this.panel92.Controls.Add(this.panel95);
            this.panel92.Controls.Add(this.panel96);
            this.panel92.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel92.Location = new System.Drawing.Point(0, 66);
            this.panel92.Name = "panel92";
            this.panel92.Size = new System.Drawing.Size(502, 22);
            this.panel92.TabIndex = 3;
            // 
            // panel93
            // 
            this.panel93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel93.Controls.Add(this.label30);
            this.panel93.Controls.Add(this.pictureBox7);
            this.panel93.Location = new System.Drawing.Point(377, 2);
            this.panel93.Name = "panel93";
            this.panel93.Size = new System.Drawing.Size(124, 17);
            this.panel93.TabIndex = 15;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Lime;
            this.label30.Location = new System.Drawing.Point(3, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(22, 14);
            this.label30.TabIndex = 6;
            this.label30.Text = "NA";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox7.Location = new System.Drawing.Point(0, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(122, 15);
            this.pictureBox7.TabIndex = 3;
            this.pictureBox7.TabStop = false;
            // 
            // panel94
            // 
            this.panel94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel94.Controls.Add(this.label31);
            this.panel94.Controls.Add(this.pictureBox8);
            this.panel94.Location = new System.Drawing.Point(1, 2);
            this.panel94.Name = "panel94";
            this.panel94.Size = new System.Drawing.Size(120, 17);
            this.panel94.TabIndex = 12;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Lime;
            this.label31.Location = new System.Drawing.Point(3, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(22, 14);
            this.label31.TabIndex = 3;
            this.label31.Text = "NA";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox8.Location = new System.Drawing.Point(0, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(118, 15);
            this.pictureBox8.TabIndex = 0;
            this.pictureBox8.TabStop = false;
            // 
            // panel95
            // 
            this.panel95.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel95.Controls.Add(this.label32);
            this.panel95.Controls.Add(this.pictureBox10);
            this.panel95.Location = new System.Drawing.Point(252, 2);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(120, 17);
            this.panel95.TabIndex = 14;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Lime;
            this.label32.Location = new System.Drawing.Point(3, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(22, 14);
            this.label32.TabIndex = 5;
            this.label32.Text = "NA";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox10.Location = new System.Drawing.Point(0, 0);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(118, 15);
            this.pictureBox10.TabIndex = 2;
            this.pictureBox10.TabStop = false;
            // 
            // panel96
            // 
            this.panel96.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel96.Controls.Add(this.label33);
            this.panel96.Controls.Add(this.pictureBox14);
            this.panel96.Location = new System.Drawing.Point(126, 2);
            this.panel96.Name = "panel96";
            this.panel96.Size = new System.Drawing.Size(120, 17);
            this.panel96.TabIndex = 13;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Lime;
            this.label33.Location = new System.Drawing.Point(3, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(22, 14);
            this.label33.TabIndex = 4;
            this.label33.Text = "NA";
            // 
            // pictureBox14
            // 
            this.pictureBox14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox14.Location = new System.Drawing.Point(0, 0);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(118, 15);
            this.pictureBox14.TabIndex = 1;
            this.pictureBox14.TabStop = false;
            // 
            // panel97
            // 
            this.panel97.Controls.Add(this.panel98);
            this.panel97.Controls.Add(this.panel99);
            this.panel97.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel97.Location = new System.Drawing.Point(0, 44);
            this.panel97.Name = "panel97";
            this.panel97.Size = new System.Drawing.Size(502, 22);
            this.panel97.TabIndex = 2;
            // 
            // panel98
            // 
            this.panel98.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel98.Controls.Add(this.ch4_ltime);
            this.panel98.Location = new System.Drawing.Point(252, 2);
            this.panel98.Name = "panel98";
            this.panel98.Size = new System.Drawing.Size(249, 17);
            this.panel98.TabIndex = 11;
            // 
            // ch4_ltime
            // 
            this.ch4_ltime.AutoSize = true;
            this.ch4_ltime.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ch4_ltime.ForeColor = System.Drawing.Color.White;
            this.ch4_ltime.Location = new System.Drawing.Point(3, 1);
            this.ch4_ltime.Name = "ch4_ltime";
            this.ch4_ltime.Size = new System.Drawing.Size(11, 14);
            this.ch4_ltime.TabIndex = 7;
            this.ch4_ltime.Text = "-";
            // 
            // panel99
            // 
            this.panel99.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel99.Controls.Add(this.label35);
            this.panel99.Location = new System.Drawing.Point(1, 2);
            this.panel99.Name = "panel99";
            this.panel99.Size = new System.Drawing.Size(245, 17);
            this.panel99.TabIndex = 8;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(3, 1);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(128, 14);
            this.label35.TabIndex = 2;
            this.label35.Text = "L A T E S T  U P D A T E S";
            // 
            // panel102
            // 
            this.panel102.Controls.Add(this.panel103);
            this.panel102.Controls.Add(this.panel104);
            this.panel102.Controls.Add(this.panel105);
            this.panel102.Controls.Add(this.panel106);
            this.panel102.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel102.Location = new System.Drawing.Point(0, 22);
            this.panel102.Name = "panel102";
            this.panel102.Size = new System.Drawing.Size(502, 22);
            this.panel102.TabIndex = 1;
            // 
            // panel103
            // 
            this.panel103.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel103.Controls.Add(this.label38);
            this.panel103.Location = new System.Drawing.Point(377, 2);
            this.panel103.Name = "panel103";
            this.panel103.Size = new System.Drawing.Size(124, 17);
            this.panel103.TabIndex = 7;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.IndianRed;
            this.label38.Location = new System.Drawing.Point(3, 1);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(11, 14);
            this.label38.TabIndex = 6;
            this.label38.Text = "-";
            // 
            // panel104
            // 
            this.panel104.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel104.Controls.Add(this.label39);
            this.panel104.Location = new System.Drawing.Point(1, 2);
            this.panel104.Name = "panel104";
            this.panel104.Size = new System.Drawing.Size(120, 17);
            this.panel104.TabIndex = 4;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.IndianRed;
            this.label39.Location = new System.Drawing.Point(3, 1);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(11, 14);
            this.label39.TabIndex = 1;
            this.label39.Text = "-";
            // 
            // panel105
            // 
            this.panel105.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel105.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel105.Controls.Add(this.label40);
            this.panel105.Location = new System.Drawing.Point(252, 2);
            this.panel105.Name = "panel105";
            this.panel105.Size = new System.Drawing.Size(120, 17);
            this.panel105.TabIndex = 6;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.IndianRed;
            this.label40.Location = new System.Drawing.Point(3, 1);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(11, 14);
            this.label40.TabIndex = 5;
            this.label40.Text = "-";
            // 
            // panel106
            // 
            this.panel106.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel106.Controls.Add(this.label41);
            this.panel106.Location = new System.Drawing.Point(126, 2);
            this.panel106.Name = "panel106";
            this.panel106.Size = new System.Drawing.Size(120, 17);
            this.panel106.TabIndex = 5;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.IndianRed;
            this.label41.Location = new System.Drawing.Point(3, 1);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(11, 14);
            this.label41.TabIndex = 2;
            this.label41.Text = "-";
            // 
            // panel107
            // 
            this.panel107.Controls.Add(this.panel108);
            this.panel107.Controls.Add(this.panel109);
            this.panel107.Controls.Add(this.panel110);
            this.panel107.Controls.Add(this.panel111);
            this.panel107.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel107.Location = new System.Drawing.Point(0, 0);
            this.panel107.Name = "panel107";
            this.panel107.Size = new System.Drawing.Size(502, 22);
            this.panel107.TabIndex = 0;
            // 
            // panel108
            // 
            this.panel108.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel108.Controls.Add(this.label42);
            this.panel108.Location = new System.Drawing.Point(377, 1);
            this.panel108.Name = "panel108";
            this.panel108.Size = new System.Drawing.Size(124, 19);
            this.panel108.TabIndex = 3;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label42.Location = new System.Drawing.Point(3, 1);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(62, 14);
            this.label42.TabIndex = 3;
            this.label42.Text = "LOW PRICE";
            // 
            // panel109
            // 
            this.panel109.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel109.Controls.Add(this.label43);
            this.panel109.Location = new System.Drawing.Point(252, 1);
            this.panel109.Name = "panel109";
            this.panel109.Size = new System.Drawing.Size(120, 19);
            this.panel109.TabIndex = 2;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label43.Location = new System.Drawing.Point(3, 1);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(62, 14);
            this.label43.TabIndex = 2;
            this.label43.Text = "HIGH PRICE";
            // 
            // panel110
            // 
            this.panel110.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel110.Controls.Add(this.label44);
            this.panel110.Location = new System.Drawing.Point(126, 1);
            this.panel110.Name = "panel110";
            this.panel110.Size = new System.Drawing.Size(120, 19);
            this.panel110.TabIndex = 1;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label44.Location = new System.Drawing.Point(3, 1);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(72, 14);
            this.label44.TabIndex = 1;
            this.label44.Text = "CLOSE PRICE";
            // 
            // panel111
            // 
            this.panel111.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel111.Controls.Add(this.label45);
            this.panel111.Location = new System.Drawing.Point(1, 1);
            this.panel111.Name = "panel111";
            this.panel111.Size = new System.Drawing.Size(120, 19);
            this.panel111.TabIndex = 0;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label45.Location = new System.Drawing.Point(3, 1);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(82, 14);
            this.label45.TabIndex = 0;
            this.label45.Text = "OPENING PRICE";
            // 
            // panel64
            // 
            this.panel64.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel64.Location = new System.Drawing.Point(0, 0);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(510, 3);
            this.panel64.TabIndex = 0;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.panel60);
            this.panel39.Controls.Add(this.panel49);
            this.panel39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(510, 307);
            this.panel39.TabIndex = 0;
            // 
            // panel60
            // 
            this.panel60.Controls.Add(this.panel70);
            this.panel60.Controls.Add(this.panel66);
            this.panel60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel60.Location = new System.Drawing.Point(0, 19);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(510, 288);
            this.panel60.TabIndex = 1;
            // 
            // panel70
            // 
            this.panel70.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel70.BackgroundImage")));
            this.panel70.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel70.Controls.Add(this.chart3);
            this.panel70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel70.Location = new System.Drawing.Point(0, 3);
            this.panel70.Name = "panel70";
            this.panel70.Padding = new System.Windows.Forms.Padding(3);
            this.panel70.Size = new System.Drawing.Size(510, 285);
            this.panel70.TabIndex = 1;
            // 
            // chart3
            // 
            this.chart3.BackColor = System.Drawing.Color.Transparent;
            this.chart3.BorderlineColor = System.Drawing.Color.Black;
            this.chart3.BorderSkin.PageColor = System.Drawing.Color.Transparent;
            chartArea2.AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea2.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea2.AxisY.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea2.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea2.BackColor = System.Drawing.Color.White;
            chartArea2.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea2.BorderColor = System.Drawing.Color.Transparent;
            chartArea2.BorderWidth = 0;
            chartArea2.InnerPlotPosition.Auto = false;
            chartArea2.InnerPlotPosition.Height = 100F;
            chartArea2.InnerPlotPosition.Width = 100F;
            chartArea2.Name = "ChartArea1";
            chartArea2.Position.Auto = false;
            chartArea2.Position.Height = 100F;
            chartArea2.Position.Width = 100F;
            this.chart3.ChartAreas.Add(chartArea2);
            this.chart3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart3.Location = new System.Drawing.Point(3, 3);
            this.chart3.Margin = new System.Windows.Forms.Padding(0);
            this.chart3.Name = "chart3";
            this.chart3.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.LabelForeColor = System.Drawing.Color.Transparent;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            series2.YValuesPerPoint = 4;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "Series2";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Name = "Series3";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series5.Name = "Series4";
            this.chart3.Series.Add(series2);
            this.chart3.Series.Add(series3);
            this.chart3.Series.Add(series4);
            this.chart3.Series.Add(series5);
            this.chart3.Size = new System.Drawing.Size(504, 279);
            this.chart3.TabIndex = 2;
            this.chart3.Text = "chart3";
            // 
            // panel66
            // 
            this.panel66.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel66.Location = new System.Drawing.Point(0, 0);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(510, 3);
            this.panel66.TabIndex = 0;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel49.Controls.Add(this.pnlbtn_CA_03);
            this.panel49.Controls.Add(this.pnlbtn_CA_04);
            this.panel49.Controls.Add(this.label4);
            this.panel49.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel49.Location = new System.Drawing.Point(0, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(510, 19);
            this.panel49.TabIndex = 0;
            // 
            // pnlbtn_CA_03
            // 
            this.pnlbtn_CA_03.Controls.Add(this.label26);
            this.pnlbtn_CA_03.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlbtn_CA_03.Location = new System.Drawing.Point(337, 0);
            this.pnlbtn_CA_03.Name = "pnlbtn_CA_03";
            this.pnlbtn_CA_03.Size = new System.Drawing.Size(77, 19);
            this.pnlbtn_CA_03.TabIndex = 21;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label26.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label26.Location = new System.Drawing.Point(24, 4);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(28, 11);
            this.label26.TabIndex = 21;
            this.label26.Text = "LINE";
            // 
            // pnlbtn_CA_04
            // 
            this.pnlbtn_CA_04.Controls.Add(this.label27);
            this.pnlbtn_CA_04.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlbtn_CA_04.Location = new System.Drawing.Point(414, 0);
            this.pnlbtn_CA_04.Name = "pnlbtn_CA_04";
            this.pnlbtn_CA_04.Size = new System.Drawing.Size(96, 19);
            this.pnlbtn_CA_04.TabIndex = 20;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label27.Location = new System.Drawing.Point(13, 4);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(73, 11);
            this.label27.TabIndex = 22;
            this.label27.Text = "PREDICTION";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label4.Location = new System.Drawing.Point(10, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 11);
            this.label4.TabIndex = 18;
            this.label4.Text = "C H A R T - A N A L Y S I S";
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel35.Controls.Add(this.panel112);
            this.panel35.Controls.Add(this.label7);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel35.Location = new System.Drawing.Point(0, 0);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(510, 19);
            this.panel35.TabIndex = 0;
            // 
            // panel112
            // 
            this.panel112.Controls.Add(this.label48);
            this.panel112.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel112.Location = new System.Drawing.Point(262, 0);
            this.panel112.Name = "panel112";
            this.panel112.Size = new System.Drawing.Size(248, 19);
            this.panel112.TabIndex = 18;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label48.Location = new System.Drawing.Point(137, 3);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(108, 14);
            this.label48.TabIndex = 1;
            this.label48.Text = "O P E N  W I N D O W";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label7.Location = new System.Drawing.Point(8, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(214, 11);
            this.label7.TabIndex = 17;
            this.label7.Text = "C H A R T - R E A L T I M E  P R I C E";
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.splitContainer3);
            this.panel34.Controls.Add(this.panel36);
            this.panel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel34.Location = new System.Drawing.Point(0, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(508, 625);
            this.panel34.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 19);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.panel61);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.panel62);
            this.splitContainer3.Panel2.Controls.Add(this.panel59);
            this.splitContainer3.Size = new System.Drawing.Size(508, 606);
            this.splitContainer3.SplitterDistance = 295;
            this.splitContainer3.TabIndex = 1;
            // 
            // panel61
            // 
            this.panel61.Controls.Add(this.panel68);
            this.panel61.Controls.Add(this.panel63);
            this.panel61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel61.Location = new System.Drawing.Point(0, 0);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(508, 295);
            this.panel61.TabIndex = 0;
            // 
            // panel68
            // 
            this.panel68.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel68.BackgroundImage")));
            this.panel68.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel68.Controls.Add(this.panel22);
            this.panel68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel68.Location = new System.Drawing.Point(0, 3);
            this.panel68.Name = "panel68";
            this.panel68.Padding = new System.Windows.Forms.Padding(3);
            this.panel68.Size = new System.Drawing.Size(508, 292);
            this.panel68.TabIndex = 1;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.chart2);
            this.panel22.Controls.Add(this.panel_chart2under);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(3, 3);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(502, 286);
            this.panel22.TabIndex = 2;
            // 
            // chart2
            // 
            this.chart2.BackColor = System.Drawing.Color.Transparent;
            this.chart2.BorderlineColor = System.Drawing.Color.Black;
            this.chart2.BorderSkin.PageColor = System.Drawing.Color.Transparent;
            chartArea3.AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea3.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea3.AxisY.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea3.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea3.BackColor = System.Drawing.Color.White;
            chartArea3.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea3.BorderColor = System.Drawing.Color.Transparent;
            chartArea3.BorderWidth = 0;
            chartArea3.InnerPlotPosition.Auto = false;
            chartArea3.InnerPlotPosition.Height = 100F;
            chartArea3.InnerPlotPosition.Width = 100F;
            chartArea3.Name = "ChartArea1";
            chartArea3.Position.Auto = false;
            chartArea3.Position.Height = 100F;
            chartArea3.Position.Width = 100F;
            this.chart2.ChartAreas.Add(chartArea3);
            this.chart2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart2.Location = new System.Drawing.Point(0, 0);
            this.chart2.Margin = new System.Windows.Forms.Padding(0);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.LabelForeColor = System.Drawing.Color.Transparent;
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            series6.YValuesPerPoint = 4;
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series7.Legend = "Legend1";
            series7.Name = "Series2";
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series8.Name = "Series3";
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series9.Name = "Series4";
            this.chart2.Series.Add(series6);
            this.chart2.Series.Add(series7);
            this.chart2.Series.Add(series8);
            this.chart2.Series.Add(series9);
            this.chart2.Size = new System.Drawing.Size(502, 172);
            this.chart2.TabIndex = 0;
            this.chart2.Text = "chart1";
            // 
            // panel_chart2under
            // 
            this.panel_chart2under.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.panel_chart2under.Controls.Add(this.panel24);
            this.panel_chart2under.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_chart2under.Location = new System.Drawing.Point(0, 172);
            this.panel_chart2under.Name = "panel_chart2under";
            this.panel_chart2under.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.panel_chart2under.Size = new System.Drawing.Size(502, 114);
            this.panel_chart2under.TabIndex = 1;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.panel80);
            this.panel24.Controls.Add(this.panel45);
            this.panel24.Controls.Add(this.panel40);
            this.panel24.Controls.Add(this.panel37);
            this.panel24.Controls.Add(this.panel30);
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(502, 120);
            this.panel24.TabIndex = 0;
            // 
            // panel80
            // 
            this.panel80.Controls.Add(this.panel81);
            this.panel80.Controls.Add(this.panel82);
            this.panel80.Controls.Add(this.panel84);
            this.panel80.Controls.Add(this.panel83);
            this.panel80.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel80.Location = new System.Drawing.Point(0, 88);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(502, 22);
            this.panel80.TabIndex = 4;
            // 
            // panel81
            // 
            this.panel81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel81.Controls.Add(this.OnYearBtn04);
            this.panel81.Controls.Add(this.pictureBox6);
            this.panel81.Location = new System.Drawing.Point(377, 2);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(124, 17);
            this.panel81.TabIndex = 19;
            // 
            // OnYearBtn04
            // 
            this.OnYearBtn04.AutoSize = true;
            this.OnYearBtn04.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnYearBtn04.ForeColor = System.Drawing.Color.Silver;
            this.OnYearBtn04.Location = new System.Drawing.Point(3, 0);
            this.OnYearBtn04.Name = "OnYearBtn04";
            this.OnYearBtn04.Size = new System.Drawing.Size(51, 14);
            this.OnYearBtn04.TabIndex = 10;
            this.OnYearBtn04.Text = "10 Years";
            this.OnYearBtn04.Click += new System.EventHandler(this.OnYearBtn04_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox6.Location = new System.Drawing.Point(0, 0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(122, 15);
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // panel82
            // 
            this.panel82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel82.Controls.Add(this.OnYearBtn01);
            this.panel82.Controls.Add(this.btn_chart2_y05);
            this.panel82.Location = new System.Drawing.Point(1, 2);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(120, 17);
            this.panel82.TabIndex = 16;
            // 
            // OnYearBtn01
            // 
            this.OnYearBtn01.AutoSize = true;
            this.OnYearBtn01.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnYearBtn01.ForeColor = System.Drawing.Color.Lime;
            this.OnYearBtn01.Location = new System.Drawing.Point(3, 0);
            this.OnYearBtn01.Name = "OnYearBtn01";
            this.OnYearBtn01.Size = new System.Drawing.Size(51, 14);
            this.OnYearBtn01.TabIndex = 4;
            this.OnYearBtn01.Text = "6 Months";
            this.OnYearBtn01.Click += new System.EventHandler(this.OnYearBtn01_Click);
            // 
            // btn_chart2_y05
            // 
            this.btn_chart2_y05.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_chart2_y05.Location = new System.Drawing.Point(0, 0);
            this.btn_chart2_y05.Name = "btn_chart2_y05";
            this.btn_chart2_y05.Size = new System.Drawing.Size(118, 15);
            this.btn_chart2_y05.TabIndex = 7;
            this.btn_chart2_y05.TabStop = false;
            this.btn_chart2_y05.Click += new System.EventHandler(this.btn_chart2_y05_Click);
            // 
            // panel84
            // 
            this.panel84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel84.Controls.Add(this.OnYearBtn02);
            this.panel84.Controls.Add(this.btn_chart2_y06);
            this.panel84.Location = new System.Drawing.Point(126, 2);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(120, 17);
            this.panel84.TabIndex = 17;
            // 
            // OnYearBtn02
            // 
            this.OnYearBtn02.AutoSize = true;
            this.OnYearBtn02.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnYearBtn02.ForeColor = System.Drawing.Color.Silver;
            this.OnYearBtn02.Location = new System.Drawing.Point(3, 0);
            this.OnYearBtn02.Name = "OnYearBtn02";
            this.OnYearBtn02.Size = new System.Drawing.Size(39, 14);
            this.OnYearBtn02.TabIndex = 8;
            this.OnYearBtn02.Text = "1 Year";
            this.OnYearBtn02.Click += new System.EventHandler(this.OnYearBtn02_Click);
            // 
            // btn_chart2_y06
            // 
            this.btn_chart2_y06.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_chart2_y06.Location = new System.Drawing.Point(0, 0);
            this.btn_chart2_y06.Name = "btn_chart2_y06";
            this.btn_chart2_y06.Size = new System.Drawing.Size(118, 15);
            this.btn_chart2_y06.TabIndex = 6;
            this.btn_chart2_y06.TabStop = false;
            this.btn_chart2_y06.Click += new System.EventHandler(this.btn_chart2_y06_Click);
            // 
            // panel83
            // 
            this.panel83.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel83.Controls.Add(this.OnYearBtn03);
            this.panel83.Controls.Add(this.btn_chart2_y07);
            this.panel83.Location = new System.Drawing.Point(252, 2);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(120, 17);
            this.panel83.TabIndex = 18;
            // 
            // OnYearBtn03
            // 
            this.OnYearBtn03.AutoSize = true;
            this.OnYearBtn03.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnYearBtn03.ForeColor = System.Drawing.Color.Silver;
            this.OnYearBtn03.Location = new System.Drawing.Point(3, 0);
            this.OnYearBtn03.Name = "OnYearBtn03";
            this.OnYearBtn03.Size = new System.Drawing.Size(45, 14);
            this.OnYearBtn03.TabIndex = 9;
            this.OnYearBtn03.Text = "3 Years";
            this.OnYearBtn03.Click += new System.EventHandler(this.OnYearBtn03_Click);
            // 
            // btn_chart2_y07
            // 
            this.btn_chart2_y07.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_chart2_y07.Location = new System.Drawing.Point(0, 0);
            this.btn_chart2_y07.Name = "btn_chart2_y07";
            this.btn_chart2_y07.Size = new System.Drawing.Size(118, 15);
            this.btn_chart2_y07.TabIndex = 5;
            this.btn_chart2_y07.TabStop = false;
            this.btn_chart2_y07.Click += new System.EventHandler(this.btn_chart2_y07_Click);
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.panel76);
            this.panel45.Controls.Add(this.panel77);
            this.panel45.Controls.Add(this.panel79);
            this.panel45.Controls.Add(this.panel78);
            this.panel45.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel45.Location = new System.Drawing.Point(0, 66);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(502, 22);
            this.panel45.TabIndex = 3;
            // 
            // panel76
            // 
            this.panel76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel76.Controls.Add(this.OnBtn04);
            this.panel76.Controls.Add(this.btn_chart2_y04);
            this.panel76.Location = new System.Drawing.Point(377, 2);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(124, 17);
            this.panel76.TabIndex = 15;
            // 
            // OnBtn04
            // 
            this.OnBtn04.AutoSize = true;
            this.OnBtn04.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnBtn04.ForeColor = System.Drawing.Color.Lime;
            this.OnBtn04.Location = new System.Drawing.Point(3, 0);
            this.OnBtn04.Name = "OnBtn04";
            this.OnBtn04.Size = new System.Drawing.Size(22, 14);
            this.OnBtn04.TabIndex = 6;
            this.OnBtn04.Text = "ON";
            this.OnBtn04.Click += new System.EventHandler(this.OnBtn04_Click);
            // 
            // btn_chart2_y04
            // 
            this.btn_chart2_y04.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_chart2_y04.Location = new System.Drawing.Point(0, 0);
            this.btn_chart2_y04.Name = "btn_chart2_y04";
            this.btn_chart2_y04.Size = new System.Drawing.Size(122, 15);
            this.btn_chart2_y04.TabIndex = 3;
            this.btn_chart2_y04.TabStop = false;
            this.btn_chart2_y04.Click += new System.EventHandler(this.btn_chart2_y04_Click);
            // 
            // panel77
            // 
            this.panel77.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel77.Controls.Add(this.OnBtn01);
            this.panel77.Controls.Add(this.btn_chart2_y01);
            this.panel77.Location = new System.Drawing.Point(1, 2);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(120, 17);
            this.panel77.TabIndex = 12;
            // 
            // OnBtn01
            // 
            this.OnBtn01.AutoSize = true;
            this.OnBtn01.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnBtn01.ForeColor = System.Drawing.Color.Lime;
            this.OnBtn01.Location = new System.Drawing.Point(3, 0);
            this.OnBtn01.Name = "OnBtn01";
            this.OnBtn01.Size = new System.Drawing.Size(22, 14);
            this.OnBtn01.TabIndex = 3;
            this.OnBtn01.Text = "ON";
            this.OnBtn01.Click += new System.EventHandler(this.OnBtn01_Click);
            // 
            // btn_chart2_y01
            // 
            this.btn_chart2_y01.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_chart2_y01.Location = new System.Drawing.Point(0, 0);
            this.btn_chart2_y01.Name = "btn_chart2_y01";
            this.btn_chart2_y01.Size = new System.Drawing.Size(118, 15);
            this.btn_chart2_y01.TabIndex = 0;
            this.btn_chart2_y01.TabStop = false;
            this.btn_chart2_y01.Click += new System.EventHandler(this.btn_chart2_y01_Click);
            // 
            // panel79
            // 
            this.panel79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel79.Controls.Add(this.OnBtn03);
            this.panel79.Controls.Add(this.btn_chart2_y03);
            this.panel79.Location = new System.Drawing.Point(252, 2);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(120, 17);
            this.panel79.TabIndex = 14;
            // 
            // OnBtn03
            // 
            this.OnBtn03.AutoSize = true;
            this.OnBtn03.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnBtn03.ForeColor = System.Drawing.Color.Lime;
            this.OnBtn03.Location = new System.Drawing.Point(3, 0);
            this.OnBtn03.Name = "OnBtn03";
            this.OnBtn03.Size = new System.Drawing.Size(22, 14);
            this.OnBtn03.TabIndex = 5;
            this.OnBtn03.Text = "ON";
            this.OnBtn03.Click += new System.EventHandler(this.OnBtn03_Click);
            // 
            // btn_chart2_y03
            // 
            this.btn_chart2_y03.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_chart2_y03.Location = new System.Drawing.Point(0, 0);
            this.btn_chart2_y03.Name = "btn_chart2_y03";
            this.btn_chart2_y03.Size = new System.Drawing.Size(118, 15);
            this.btn_chart2_y03.TabIndex = 2;
            this.btn_chart2_y03.TabStop = false;
            this.btn_chart2_y03.Click += new System.EventHandler(this.btn_chart2_y03_Click);
            // 
            // panel78
            // 
            this.panel78.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel78.Controls.Add(this.OnBtn02);
            this.panel78.Controls.Add(this.btn_chart2_y02);
            this.panel78.Location = new System.Drawing.Point(126, 2);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(120, 17);
            this.panel78.TabIndex = 13;
            // 
            // OnBtn02
            // 
            this.OnBtn02.AutoSize = true;
            this.OnBtn02.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnBtn02.ForeColor = System.Drawing.Color.Lime;
            this.OnBtn02.Location = new System.Drawing.Point(3, 0);
            this.OnBtn02.Name = "OnBtn02";
            this.OnBtn02.Size = new System.Drawing.Size(22, 14);
            this.OnBtn02.TabIndex = 4;
            this.OnBtn02.Text = "ON";
            this.OnBtn02.Click += new System.EventHandler(this.OnBtn02_Click);
            // 
            // btn_chart2_y02
            // 
            this.btn_chart2_y02.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btn_chart2_y02.Location = new System.Drawing.Point(0, 0);
            this.btn_chart2_y02.Name = "btn_chart2_y02";
            this.btn_chart2_y02.Size = new System.Drawing.Size(118, 15);
            this.btn_chart2_y02.TabIndex = 1;
            this.btn_chart2_y02.TabStop = false;
            this.btn_chart2_y02.Click += new System.EventHandler(this.btn_chart2_y02_Click);
            // 
            // panel40
            // 
            this.panel40.Controls.Add(this.panel14);
            this.panel40.Controls.Add(this.panel73);
            this.panel40.Controls.Add(this.panel75);
            this.panel40.Controls.Add(this.panel74);
            this.panel40.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel40.Location = new System.Drawing.Point(0, 44);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(502, 22);
            this.panel40.TabIndex = 2;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.lbmin_lp);
            this.panel14.Location = new System.Drawing.Point(377, 2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(124, 17);
            this.panel14.TabIndex = 11;
            // 
            // lbmin_lp
            // 
            this.lbmin_lp.AutoSize = true;
            this.lbmin_lp.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmin_lp.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lbmin_lp.Location = new System.Drawing.Point(3, 1);
            this.lbmin_lp.Name = "lbmin_lp";
            this.lbmin_lp.Size = new System.Drawing.Size(11, 14);
            this.lbmin_lp.TabIndex = 7;
            this.lbmin_lp.Text = "-";
            // 
            // panel73
            // 
            this.panel73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel73.Controls.Add(this.lbmin_op);
            this.panel73.Location = new System.Drawing.Point(1, 2);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(120, 17);
            this.panel73.TabIndex = 8;
            // 
            // lbmin_op
            // 
            this.lbmin_op.AutoSize = true;
            this.lbmin_op.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmin_op.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lbmin_op.Location = new System.Drawing.Point(3, 1);
            this.lbmin_op.Name = "lbmin_op";
            this.lbmin_op.Size = new System.Drawing.Size(11, 14);
            this.lbmin_op.TabIndex = 2;
            this.lbmin_op.Text = "-";
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel75.Controls.Add(this.lbmin_cp);
            this.panel75.Location = new System.Drawing.Point(126, 2);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(120, 17);
            this.panel75.TabIndex = 9;
            // 
            // lbmin_cp
            // 
            this.lbmin_cp.AutoSize = true;
            this.lbmin_cp.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmin_cp.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lbmin_cp.Location = new System.Drawing.Point(3, 1);
            this.lbmin_cp.Name = "lbmin_cp";
            this.lbmin_cp.Size = new System.Drawing.Size(11, 14);
            this.lbmin_cp.TabIndex = 3;
            this.lbmin_cp.Text = "-";
            // 
            // panel74
            // 
            this.panel74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel74.Controls.Add(this.lbmin_hp);
            this.panel74.Location = new System.Drawing.Point(252, 2);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(120, 17);
            this.panel74.TabIndex = 10;
            // 
            // lbmin_hp
            // 
            this.lbmin_hp.AutoSize = true;
            this.lbmin_hp.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmin_hp.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lbmin_hp.Location = new System.Drawing.Point(3, 1);
            this.lbmin_hp.Name = "lbmin_hp";
            this.lbmin_hp.Size = new System.Drawing.Size(11, 14);
            this.lbmin_hp.TabIndex = 4;
            this.lbmin_hp.Text = "-";
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.panel46);
            this.panel37.Controls.Add(this.panel72);
            this.panel37.Controls.Add(this.panel47);
            this.panel37.Controls.Add(this.panel71);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel37.Location = new System.Drawing.Point(0, 22);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(502, 22);
            this.panel37.TabIndex = 1;
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel46.Controls.Add(this.lbmax_lp);
            this.panel46.Location = new System.Drawing.Point(377, 2);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(124, 17);
            this.panel46.TabIndex = 7;
            // 
            // lbmax_lp
            // 
            this.lbmax_lp.AutoSize = true;
            this.lbmax_lp.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmax_lp.ForeColor = System.Drawing.Color.IndianRed;
            this.lbmax_lp.Location = new System.Drawing.Point(3, 1);
            this.lbmax_lp.Name = "lbmax_lp";
            this.lbmax_lp.Size = new System.Drawing.Size(11, 14);
            this.lbmax_lp.TabIndex = 6;
            this.lbmax_lp.Text = "-";
            // 
            // panel72
            // 
            this.panel72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel72.Controls.Add(this.lbmax_op);
            this.panel72.Location = new System.Drawing.Point(1, 2);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(120, 17);
            this.panel72.TabIndex = 4;
            // 
            // lbmax_op
            // 
            this.lbmax_op.AutoSize = true;
            this.lbmax_op.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmax_op.ForeColor = System.Drawing.Color.IndianRed;
            this.lbmax_op.Location = new System.Drawing.Point(3, 1);
            this.lbmax_op.Name = "lbmax_op";
            this.lbmax_op.Size = new System.Drawing.Size(11, 14);
            this.lbmax_op.TabIndex = 1;
            this.lbmax_op.Text = "-";
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel47.Controls.Add(this.lbmax_hp);
            this.panel47.Location = new System.Drawing.Point(252, 2);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(120, 17);
            this.panel47.TabIndex = 6;
            // 
            // lbmax_hp
            // 
            this.lbmax_hp.AutoSize = true;
            this.lbmax_hp.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmax_hp.ForeColor = System.Drawing.Color.IndianRed;
            this.lbmax_hp.Location = new System.Drawing.Point(3, 1);
            this.lbmax_hp.Name = "lbmax_hp";
            this.lbmax_hp.Size = new System.Drawing.Size(11, 14);
            this.lbmax_hp.TabIndex = 5;
            this.lbmax_hp.Text = "-";
            // 
            // panel71
            // 
            this.panel71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel71.Controls.Add(this.lbmax_cp);
            this.panel71.Location = new System.Drawing.Point(126, 2);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(120, 17);
            this.panel71.TabIndex = 5;
            // 
            // lbmax_cp
            // 
            this.lbmax_cp.AutoSize = true;
            this.lbmax_cp.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbmax_cp.ForeColor = System.Drawing.Color.IndianRed;
            this.lbmax_cp.Location = new System.Drawing.Point(3, 1);
            this.lbmax_cp.Name = "lbmax_cp";
            this.lbmax_cp.Size = new System.Drawing.Size(11, 14);
            this.lbmax_cp.TabIndex = 2;
            this.lbmax_cp.Text = "-";
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.panel44);
            this.panel30.Controls.Add(this.panel43);
            this.panel30.Controls.Add(this.panel42);
            this.panel30.Controls.Add(this.panel41);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel30.Location = new System.Drawing.Point(0, 0);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(502, 22);
            this.panel30.TabIndex = 0;
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel44.Controls.Add(this.label24);
            this.panel44.Location = new System.Drawing.Point(377, 1);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(124, 19);
            this.panel44.TabIndex = 3;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label24.Location = new System.Drawing.Point(3, 1);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(62, 14);
            this.label24.TabIndex = 3;
            this.label24.Text = "LOW PRICE";
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel43.Controls.Add(this.label17);
            this.panel43.Location = new System.Drawing.Point(252, 1);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(120, 19);
            this.panel43.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.Location = new System.Drawing.Point(3, 1);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(62, 14);
            this.label17.TabIndex = 2;
            this.label17.Text = "HIGH PRICE";
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel42.Controls.Add(this.label15);
            this.panel42.Location = new System.Drawing.Point(126, 1);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(120, 19);
            this.panel42.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label15.Location = new System.Drawing.Point(3, 1);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 14);
            this.label15.TabIndex = 1;
            this.label15.Text = "CLOSE PRICE";
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(27)))), ((int)(((byte)(27)))));
            this.panel41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel41.Controls.Add(this.label13);
            this.panel41.Location = new System.Drawing.Point(1, 1);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(120, 19);
            this.panel41.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label13.Location = new System.Drawing.Point(3, 1);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 14);
            this.label13.TabIndex = 0;
            this.label13.Text = "OPENING PRICE";
            // 
            // panel63
            // 
            this.panel63.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel63.Location = new System.Drawing.Point(0, 0);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(508, 3);
            this.panel63.TabIndex = 0;
            // 
            // panel62
            // 
            this.panel62.Controls.Add(this.panel69);
            this.panel62.Controls.Add(this.panel65);
            this.panel62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel62.Location = new System.Drawing.Point(0, 19);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(508, 288);
            this.panel62.TabIndex = 1;
            // 
            // panel69
            // 
            this.panel69.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel69.BackgroundImage")));
            this.panel69.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel69.Location = new System.Drawing.Point(0, 3);
            this.panel69.Name = "panel69";
            this.panel69.Padding = new System.Windows.Forms.Padding(3);
            this.panel69.Size = new System.Drawing.Size(508, 285);
            this.panel69.TabIndex = 1;
            // 
            // panel65
            // 
            this.panel65.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel65.Location = new System.Drawing.Point(0, 0);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(508, 3);
            this.panel65.TabIndex = 0;
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel59.Controls.Add(this.label14);
            this.panel59.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel59.Location = new System.Drawing.Point(0, 0);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(508, 19);
            this.panel59.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label14.Location = new System.Drawing.Point(9, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 11);
            this.label14.TabIndex = 19;
            this.label14.Text = "S T O C K  P R I C E";
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel36.Controls.Add(this.panel85);
            this.panel36.Controls.Add(this.label10);
            this.panel36.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel36.Location = new System.Drawing.Point(0, 0);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(508, 19);
            this.panel36.TabIndex = 0;
            // 
            // panel85
            // 
            this.panel85.Controls.Add(this.btn_chart2);
            this.panel85.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel85.Location = new System.Drawing.Point(347, 0);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(161, 19);
            this.panel85.TabIndex = 19;
            // 
            // btn_chart2
            // 
            this.btn_chart2.AutoSize = true;
            this.btn_chart2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_chart2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_chart2.Location = new System.Drawing.Point(50, 2);
            this.btn_chart2.Name = "btn_chart2";
            this.btn_chart2.Size = new System.Drawing.Size(108, 14);
            this.btn_chart2.TabIndex = 0;
            this.btn_chart2.Text = "O P E N  W I N D O W";
            this.btn_chart2.Click += new System.EventHandler(this.btn_chart2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label10.Location = new System.Drawing.Point(9, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(138, 11);
            this.label10.TabIndex = 18;
            this.label10.Text = "C H A R T - T R E N D S";
            // 
            // panel_tmp2
            // 
            this.panel_tmp2.Controls.Add(this.label18);
            this.panel_tmp2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_tmp2.Location = new System.Drawing.Point(0, 0);
            this.panel_tmp2.Name = "panel_tmp2";
            this.panel_tmp2.Size = new System.Drawing.Size(1023, 625);
            this.panel_tmp2.TabIndex = 8;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label18.Location = new System.Drawing.Point(16, 22);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(38, 12);
            this.label18.TabIndex = 3;
            this.label18.Text = "TMP2";
            // 
            // panel_tmp1
            // 
            this.panel_tmp1.Controls.Add(this.label19);
            this.panel_tmp1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_tmp1.Location = new System.Drawing.Point(0, 0);
            this.panel_tmp1.Name = "panel_tmp1";
            this.panel_tmp1.Size = new System.Drawing.Size(1023, 625);
            this.panel_tmp1.TabIndex = 7;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label19.Location = new System.Drawing.Point(16, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 12);
            this.label19.TabIndex = 3;
            this.label19.Text = "TMP1";
            // 
            // panel_prediction
            // 
            this.panel_prediction.Controls.Add(this.label20);
            this.panel_prediction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_prediction.Location = new System.Drawing.Point(0, 0);
            this.panel_prediction.Name = "panel_prediction";
            this.panel_prediction.Size = new System.Drawing.Size(1023, 625);
            this.panel_prediction.TabIndex = 3;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label20.Location = new System.Drawing.Point(13, 13);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(37, 12);
            this.label20.TabIndex = 3;
            this.label20.Text = "PRED";
            // 
            // panel_tracking
            // 
            this.panel_tracking.Controls.Add(this.label21);
            this.panel_tracking.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_tracking.Location = new System.Drawing.Point(0, 0);
            this.panel_tracking.Name = "panel_tracking";
            this.panel_tracking.Size = new System.Drawing.Size(1023, 625);
            this.panel_tracking.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label21.Location = new System.Drawing.Point(34, 34);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(37, 12);
            this.label21.TabIndex = 3;
            this.label21.Text = "Track";
            // 
            // panel_list
            // 
            this.panel_list.Controls.Add(this.label22);
            this.panel_list.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_list.Location = new System.Drawing.Point(0, 0);
            this.panel_list.Name = "panel_list";
            this.panel_list.Size = new System.Drawing.Size(1023, 625);
            this.panel_list.TabIndex = 4;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label22.Location = new System.Drawing.Point(16, 27);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(25, 12);
            this.label22.TabIndex = 3;
            this.label22.Text = "List";
            // 
            // panel_stock
            // 
            this.panel_stock.Controls.Add(this.label23);
            this.panel_stock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_stock.Location = new System.Drawing.Point(0, 0);
            this.panel_stock.Name = "panel_stock";
            this.panel_stock.Size = new System.Drawing.Size(1023, 625);
            this.panel_stock.TabIndex = 5;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label23.Location = new System.Drawing.Point(16, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(36, 12);
            this.label23.TabIndex = 3;
            this.label23.Text = "Stock";
            // 
            // panel_overview
            // 
            this.panel_overview.Controls.Add(this.label50);
            this.panel_overview.Controls.Add(this.label16);
            this.panel_overview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_overview.Location = new System.Drawing.Point(0, 0);
            this.panel_overview.Name = "panel_overview";
            this.panel_overview.Size = new System.Drawing.Size(1023, 625);
            this.panel_overview.TabIndex = 4;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.Color.White;
            this.label50.Location = new System.Drawing.Point(407, 294);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(197, 36);
            this.label50.TabIndex = 16;
            this.label50.Text = "XTERMINAL";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label16.Location = new System.Drawing.Point(10, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(57, 12);
            this.label16.TabIndex = 1;
            this.label16.Text = "Overview";
            // 
            // panel29
            // 
            this.panel29.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel29.Location = new System.Drawing.Point(262, 656);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(1023, 10);
            this.panel29.TabIndex = 5;
            // 
            // panel28
            // 
            this.panel28.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel28.Location = new System.Drawing.Point(262, 26);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(1023, 5);
            this.panel28.TabIndex = 4;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.label46);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel26.Location = new System.Drawing.Point(262, 666);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(1023, 51);
            this.panel26.TabIndex = 3;
            // 
            // label46
            // 
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.ForeColor = System.Drawing.Color.White;
            this.label46.Location = new System.Drawing.Point(887, 13);
            this.label46.Name = "label46";
            this.label46.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label46.Size = new System.Drawing.Size(128, 20);
            this.label46.TabIndex = 0;
            this.label46.Text = "Version Beta 0.015.12";
            this.label46.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.pictureBox13);
            this.panel18.Controls.Add(this.panel20);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel18.Location = new System.Drawing.Point(236, 26);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(26, 691);
            this.panel18.TabIndex = 2;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(0, 0);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(25, 640);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 4;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Visible = false;
            // 
            // panel20
            // 
            this.panel20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel20.Location = new System.Drawing.Point(0, 640);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(26, 51);
            this.panel20.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Controls.Add(this.panel12);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(236, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1049, 26);
            this.panel1.TabIndex = 1;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.panel_searchbox);
            this.panel10.Controls.Add(this.panel_search);
            this.panel10.Controls.Add(this.btn_search);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel10.ForeColor = System.Drawing.Color.White;
            this.panel10.Location = new System.Drawing.Point(539, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(510, 26);
            this.panel10.TabIndex = 0;
            // 
            // panel_searchbox
            // 
            this.panel_searchbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_searchbox.Controls.Add(this.tb_searchbox);
            this.panel_searchbox.Location = new System.Drawing.Point(97, 0);
            this.panel_searchbox.Name = "panel_searchbox";
            this.panel_searchbox.Size = new System.Drawing.Size(297, 26);
            this.panel_searchbox.TabIndex = 2;
            // 
            // tb_searchbox
            // 
            this.tb_searchbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.tb_searchbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_searchbox.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_searchbox.ForeColor = System.Drawing.Color.White;
            this.tb_searchbox.Location = new System.Drawing.Point(5, 5);
            this.tb_searchbox.Name = "tb_searchbox";
            this.tb_searchbox.Size = new System.Drawing.Size(278, 15);
            this.tb_searchbox.TabIndex = 0;
            this.tb_searchbox.TabStop = false;
            // 
            // panel_search
            // 
            this.panel_search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel_search.Controls.Add(this.label12);
            this.panel_search.Controls.Add(this.label6);
            this.panel_search.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_search.Location = new System.Drawing.Point(0, 0);
            this.panel_search.Name = "panel_search";
            this.panel_search.Size = new System.Drawing.Size(91, 26);
            this.panel_search.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label12.Location = new System.Drawing.Point(10, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 11);
            this.label12.TabIndex = 18;
            this.label12.Text = "S E A R C H";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label6.Location = new System.Drawing.Point(10, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 11);
            this.label6.TabIndex = 17;
            this.label6.Text = "S E A R C H";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // btn_search
            // 
            this.btn_search.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_search.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_search.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.ForeColor = System.Drawing.Color.White;
            this.btn_search.Location = new System.Drawing.Point(402, 0);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(108, 26);
            this.btn_search.TabIndex = 0;
            this.btn_search.TabStop = false;
            this.btn_search.Text = "S E A R C H";
            this.btn_search.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.panel_stckName);
            this.panel12.Controls.Add(this.panel_upStockName);
            this.panel12.Controls.Add(this.panel16);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(533, 26);
            this.panel12.TabIndex = 1;
            // 
            // panel_stckName
            // 
            this.panel_stckName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_stckName.Controls.Add(this.lb_stockName);
            this.panel_stckName.Location = new System.Drawing.Point(123, 0);
            this.panel_stckName.Name = "panel_stckName";
            this.panel_stckName.Size = new System.Drawing.Size(234, 26);
            this.panel_stckName.TabIndex = 3;
            // 
            // lb_stockName
            // 
            this.lb_stockName.AutoSize = true;
            this.lb_stockName.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lb_stockName.ForeColor = System.Drawing.Color.White;
            this.lb_stockName.Location = new System.Drawing.Point(6, 7);
            this.lb_stockName.Name = "lb_stockName";
            this.lb_stockName.Size = new System.Drawing.Size(10, 11);
            this.lb_stockName.TabIndex = 19;
            this.lb_stockName.Text = "-";
            // 
            // panel_upStockName
            // 
            this.panel_upStockName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel_upStockName.Controls.Add(this.lb_upstockName);
            this.panel_upStockName.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_upStockName.Location = new System.Drawing.Point(26, 0);
            this.panel_upStockName.Name = "panel_upStockName";
            this.panel_upStockName.Size = new System.Drawing.Size(91, 26);
            this.panel_upStockName.TabIndex = 3;
            // 
            // lb_upstockName
            // 
            this.lb_upstockName.AutoSize = true;
            this.lb_upstockName.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lb_upstockName.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lb_upstockName.Location = new System.Drawing.Point(13, 8);
            this.lb_upstockName.Name = "lb_upstockName";
            this.lb_upstockName.Size = new System.Drawing.Size(60, 11);
            this.lb_upstockName.TabIndex = 16;
            this.lb_upstockName.Text = "S T O C K";
            // 
            // panel16
            // 
            this.panel16.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(26, 26);
            this.panel16.TabIndex = 2;
            // 
            // panel_side
            // 
            this.panel_side.Controls.Add(this.panel4);
            this.panel_side.Controls.Add(this.panel3);
            this.panel_side.Controls.Add(this.panel2);
            this.panel_side.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_side.Location = new System.Drawing.Point(0, 0);
            this.panel_side.Name = "panel_side";
            this.panel_side.Size = new System.Drawing.Size(236, 717);
            this.panel_side.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel55);
            this.panel4.Controls.Add(this.panel52);
            this.panel4.Controls.Add(this.panel32);
            this.panel4.Controls.Add(this.btbase9);
            this.panel4.Controls.Add(this.btbase8);
            this.panel4.Controls.Add(this.btbase7);
            this.panel4.Controls.Add(this.btbase6);
            this.panel4.Controls.Add(this.btbase5);
            this.panel4.Controls.Add(this.btbase4);
            this.panel4.Controls.Add(this.btbase3);
            this.panel4.Controls.Add(this.btbase2);
            this.panel4.Controls.Add(this.btbase1);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 205);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(236, 461);
            this.panel4.TabIndex = 2;
            // 
            // panel55
            // 
            this.panel55.Controls.Add(this.pictureBox12);
            this.panel55.Controls.Add(this.panel56);
            this.panel55.Controls.Add(this.panel57);
            this.panel55.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel55.Location = new System.Drawing.Point(15, 341);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(221, 40);
            this.panel55.TabIndex = 13;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox12.Location = new System.Drawing.Point(10, 0);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(195, 40);
            this.pictureBox12.TabIndex = 10;
            this.pictureBox12.TabStop = false;
            // 
            // panel56
            // 
            this.panel56.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel56.Location = new System.Drawing.Point(5, 0);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(5, 40);
            this.panel56.TabIndex = 9;
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel57.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel57.Location = new System.Drawing.Point(0, 0);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(5, 40);
            this.panel57.TabIndex = 0;
            // 
            // panel52
            // 
            this.panel52.Controls.Add(this.pictureBox11);
            this.panel52.Controls.Add(this.panel53);
            this.panel52.Controls.Add(this.panel54);
            this.panel52.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel52.Location = new System.Drawing.Point(15, 381);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(221, 40);
            this.panel52.TabIndex = 12;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox11.Location = new System.Drawing.Point(10, 0);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(195, 40);
            this.pictureBox11.TabIndex = 10;
            this.pictureBox11.TabStop = false;
            // 
            // panel53
            // 
            this.panel53.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel53.Location = new System.Drawing.Point(5, 0);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(5, 40);
            this.panel53.TabIndex = 9;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel54.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel54.Location = new System.Drawing.Point(0, 0);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(5, 40);
            this.panel54.TabIndex = 0;
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.pictureBox1);
            this.panel32.Controls.Add(this.panel50);
            this.panel32.Controls.Add(this.panel51);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel32.Location = new System.Drawing.Point(15, 240);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(221, 40);
            this.panel32.TabIndex = 11;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox1.Location = new System.Drawing.Point(10, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(195, 40);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // panel50
            // 
            this.panel50.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel50.Location = new System.Drawing.Point(5, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(5, 40);
            this.panel50.TabIndex = 9;
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.panel51.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel51.Location = new System.Drawing.Point(0, 0);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(5, 40);
            this.panel51.TabIndex = 0;
            // 
            // btbase9
            // 
            this.btbase9.Controls.Add(this.pictureBox9);
            this.btbase9.Controls.Add(this.panel48);
            this.btbase9.Controls.Add(this.panel27);
            this.btbase9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btbase9.Location = new System.Drawing.Point(15, 421);
            this.btbase9.Name = "btbase9";
            this.btbase9.Size = new System.Drawing.Size(221, 40);
            this.btbase9.TabIndex = 9;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureBox9.Location = new System.Drawing.Point(10, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(195, 40);
            this.pictureBox9.TabIndex = 10;
            this.pictureBox9.TabStop = false;
            // 
            // panel48
            // 
            this.panel48.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel48.Location = new System.Drawing.Point(5, 0);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(5, 40);
            this.panel48.TabIndex = 9;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel27.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel27.Location = new System.Drawing.Point(0, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(5, 40);
            this.panel27.TabIndex = 0;
            // 
            // btbase8
            // 
            this.btbase8.Controls.Add(this.lablsidebnt08);
            this.btbase8.Controls.Add(this.sidebnt08);
            this.btbase8.Controls.Add(this.clablsidebnt08);
            this.btbase8.Controls.Add(this.panel25);
            this.btbase8.Dock = System.Windows.Forms.DockStyle.Top;
            this.btbase8.Location = new System.Drawing.Point(15, 210);
            this.btbase8.Name = "btbase8";
            this.btbase8.Size = new System.Drawing.Size(221, 30);
            this.btbase8.TabIndex = 8;
            // 
            // lablsidebnt08
            // 
            this.lablsidebnt08.AutoSize = true;
            this.lablsidebnt08.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lablsidebnt08.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lablsidebnt08.Location = new System.Drawing.Point(19, 10);
            this.lablsidebnt08.Name = "lablsidebnt08";
            this.lablsidebnt08.Size = new System.Drawing.Size(109, 11);
            this.lablsidebnt08.TabIndex = 24;
            this.lablsidebnt08.Text = "BITCOIN ANALYSIS";
            this.lablsidebnt08.Click += new System.EventHandler(this.lablsidebnt08_Click);
            // 
            // sidebnt08
            // 
            this.sidebnt08.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebnt08.Location = new System.Drawing.Point(10, 0);
            this.sidebnt08.Name = "sidebnt08";
            this.sidebnt08.Size = new System.Drawing.Size(195, 30);
            this.sidebnt08.TabIndex = 9;
            this.sidebnt08.TabStop = false;
            this.sidebnt08.Click += new System.EventHandler(this.sidebnt08_Click);
            // 
            // clablsidebnt08
            // 
            this.clablsidebnt08.Dock = System.Windows.Forms.DockStyle.Left;
            this.clablsidebnt08.Location = new System.Drawing.Point(5, 0);
            this.clablsidebnt08.Name = "clablsidebnt08";
            this.clablsidebnt08.Size = new System.Drawing.Size(5, 30);
            this.clablsidebnt08.TabIndex = 8;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel25.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel25.Location = new System.Drawing.Point(0, 0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(5, 30);
            this.panel25.TabIndex = 0;
            // 
            // btbase7
            // 
            this.btbase7.Controls.Add(this.lablsidebnt07);
            this.btbase7.Controls.Add(this.sidebnt07);
            this.btbase7.Controls.Add(this.clablsidebnt07);
            this.btbase7.Controls.Add(this.panel23);
            this.btbase7.Dock = System.Windows.Forms.DockStyle.Top;
            this.btbase7.Location = new System.Drawing.Point(15, 180);
            this.btbase7.Name = "btbase7";
            this.btbase7.Size = new System.Drawing.Size(221, 30);
            this.btbase7.TabIndex = 7;
            // 
            // lablsidebnt07
            // 
            this.lablsidebnt07.AutoSize = true;
            this.lablsidebnt07.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lablsidebnt07.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lablsidebnt07.Location = new System.Drawing.Point(19, 10);
            this.lablsidebnt07.Name = "lablsidebnt07";
            this.lablsidebnt07.Size = new System.Drawing.Size(87, 11);
            this.lablsidebnt07.TabIndex = 23;
            this.lablsidebnt07.Text = "BITCOIN PRICE";
            this.lablsidebnt07.Click += new System.EventHandler(this.lablsidebnt07_Click);
            // 
            // sidebnt07
            // 
            this.sidebnt07.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebnt07.Location = new System.Drawing.Point(10, 0);
            this.sidebnt07.Name = "sidebnt07";
            this.sidebnt07.Size = new System.Drawing.Size(195, 30);
            this.sidebnt07.TabIndex = 8;
            this.sidebnt07.TabStop = false;
            this.sidebnt07.Click += new System.EventHandler(this.sidebnt07_Click);
            // 
            // clablsidebnt07
            // 
            this.clablsidebnt07.Dock = System.Windows.Forms.DockStyle.Left;
            this.clablsidebnt07.Location = new System.Drawing.Point(5, 0);
            this.clablsidebnt07.Name = "clablsidebnt07";
            this.clablsidebnt07.Size = new System.Drawing.Size(5, 30);
            this.clablsidebnt07.TabIndex = 7;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel23.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel23.Location = new System.Drawing.Point(0, 0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(5, 30);
            this.panel23.TabIndex = 0;
            // 
            // btbase6
            // 
            this.btbase6.Controls.Add(this.lablsidebnt06);
            this.btbase6.Controls.Add(this.sidebnt06);
            this.btbase6.Controls.Add(this.clablsidebnt06);
            this.btbase6.Controls.Add(this.panel21);
            this.btbase6.Dock = System.Windows.Forms.DockStyle.Top;
            this.btbase6.Location = new System.Drawing.Point(15, 150);
            this.btbase6.Name = "btbase6";
            this.btbase6.Size = new System.Drawing.Size(221, 30);
            this.btbase6.TabIndex = 6;
            // 
            // lablsidebnt06
            // 
            this.lablsidebnt06.AutoSize = true;
            this.lablsidebnt06.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lablsidebnt06.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lablsidebnt06.Location = new System.Drawing.Point(19, 10);
            this.lablsidebnt06.Name = "lablsidebnt06";
            this.lablsidebnt06.Size = new System.Drawing.Size(105, 11);
            this.lablsidebnt06.TabIndex = 22;
            this.lablsidebnt06.Text = "STOCK TRACKING";
            this.lablsidebnt06.Click += new System.EventHandler(this.lablsidebnt06_Click);
            // 
            // sidebnt06
            // 
            this.sidebnt06.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebnt06.Location = new System.Drawing.Point(10, 0);
            this.sidebnt06.Name = "sidebnt06";
            this.sidebnt06.Size = new System.Drawing.Size(195, 30);
            this.sidebnt06.TabIndex = 7;
            this.sidebnt06.TabStop = false;
            this.sidebnt06.Click += new System.EventHandler(this.sidebnt06_Click);
            // 
            // clablsidebnt06
            // 
            this.clablsidebnt06.Dock = System.Windows.Forms.DockStyle.Left;
            this.clablsidebnt06.Location = new System.Drawing.Point(5, 0);
            this.clablsidebnt06.Name = "clablsidebnt06";
            this.clablsidebnt06.Size = new System.Drawing.Size(5, 30);
            this.clablsidebnt06.TabIndex = 6;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel21.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(5, 30);
            this.panel21.TabIndex = 0;
            // 
            // btbase5
            // 
            this.btbase5.Controls.Add(this.lablsidebnt05);
            this.btbase5.Controls.Add(this.sidebnt05);
            this.btbase5.Controls.Add(this.clablsidebnt05);
            this.btbase5.Controls.Add(this.panel19);
            this.btbase5.Dock = System.Windows.Forms.DockStyle.Top;
            this.btbase5.Location = new System.Drawing.Point(15, 120);
            this.btbase5.Name = "btbase5";
            this.btbase5.Size = new System.Drawing.Size(221, 30);
            this.btbase5.TabIndex = 5;
            // 
            // lablsidebnt05
            // 
            this.lablsidebnt05.AutoSize = true;
            this.lablsidebnt05.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lablsidebnt05.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lablsidebnt05.Location = new System.Drawing.Point(19, 10);
            this.lablsidebnt05.Name = "lablsidebnt05";
            this.lablsidebnt05.Size = new System.Drawing.Size(44, 11);
            this.lablsidebnt05.TabIndex = 21;
            this.lablsidebnt05.Text = "STOCK";
            this.lablsidebnt05.Click += new System.EventHandler(this.lablsidebnt05_Click);
            // 
            // sidebnt05
            // 
            this.sidebnt05.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebnt05.Location = new System.Drawing.Point(10, 0);
            this.sidebnt05.Name = "sidebnt05";
            this.sidebnt05.Size = new System.Drawing.Size(195, 30);
            this.sidebnt05.TabIndex = 6;
            this.sidebnt05.TabStop = false;
            this.sidebnt05.Click += new System.EventHandler(this.sidebnt05_Click);
            // 
            // clablsidebnt05
            // 
            this.clablsidebnt05.Dock = System.Windows.Forms.DockStyle.Left;
            this.clablsidebnt05.Location = new System.Drawing.Point(5, 0);
            this.clablsidebnt05.Name = "clablsidebnt05";
            this.clablsidebnt05.Size = new System.Drawing.Size(5, 30);
            this.clablsidebnt05.TabIndex = 5;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel19.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(5, 30);
            this.panel19.TabIndex = 0;
            // 
            // btbase4
            // 
            this.btbase4.Controls.Add(this.lablsidebnt04);
            this.btbase4.Controls.Add(this.sidebnt04);
            this.btbase4.Controls.Add(this.clablsidebnt04);
            this.btbase4.Controls.Add(this.panel17);
            this.btbase4.Dock = System.Windows.Forms.DockStyle.Top;
            this.btbase4.Location = new System.Drawing.Point(15, 90);
            this.btbase4.Name = "btbase4";
            this.btbase4.Size = new System.Drawing.Size(221, 30);
            this.btbase4.TabIndex = 4;
            // 
            // lablsidebnt04
            // 
            this.lablsidebnt04.AutoSize = true;
            this.lablsidebnt04.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lablsidebnt04.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lablsidebnt04.Location = new System.Drawing.Point(19, 10);
            this.lablsidebnt04.Name = "lablsidebnt04";
            this.lablsidebnt04.Size = new System.Drawing.Size(72, 11);
            this.lablsidebnt04.TabIndex = 20;
            this.lablsidebnt04.Text = "STOCK LIST";
            this.lablsidebnt04.Click += new System.EventHandler(this.lablsidebnt04_Click);
            // 
            // sidebnt04
            // 
            this.sidebnt04.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebnt04.Location = new System.Drawing.Point(10, 0);
            this.sidebnt04.Name = "sidebnt04";
            this.sidebnt04.Size = new System.Drawing.Size(195, 30);
            this.sidebnt04.TabIndex = 5;
            this.sidebnt04.TabStop = false;
            this.sidebnt04.Click += new System.EventHandler(this.sidebnt04_Click);
            // 
            // clablsidebnt04
            // 
            this.clablsidebnt04.Dock = System.Windows.Forms.DockStyle.Left;
            this.clablsidebnt04.Location = new System.Drawing.Point(5, 0);
            this.clablsidebnt04.Name = "clablsidebnt04";
            this.clablsidebnt04.Size = new System.Drawing.Size(5, 30);
            this.clablsidebnt04.TabIndex = 4;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel17.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(5, 30);
            this.panel17.TabIndex = 0;
            // 
            // btbase3
            // 
            this.btbase3.Controls.Add(this.lablsidebnt03);
            this.btbase3.Controls.Add(this.sidebnt03);
            this.btbase3.Controls.Add(this.clablsidebnt03);
            this.btbase3.Controls.Add(this.panel15);
            this.btbase3.Dock = System.Windows.Forms.DockStyle.Top;
            this.btbase3.Location = new System.Drawing.Point(15, 60);
            this.btbase3.Name = "btbase3";
            this.btbase3.Size = new System.Drawing.Size(221, 30);
            this.btbase3.TabIndex = 3;
            // 
            // lablsidebnt03
            // 
            this.lablsidebnt03.AutoSize = true;
            this.lablsidebnt03.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lablsidebnt03.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lablsidebnt03.Location = new System.Drawing.Point(19, 10);
            this.lablsidebnt03.Name = "lablsidebnt03";
            this.lablsidebnt03.Size = new System.Drawing.Size(116, 11);
            this.lablsidebnt03.TabIndex = 19;
            this.lablsidebnt03.Text = "STOCK PREDICTION";
            this.lablsidebnt03.Click += new System.EventHandler(this.lablsidebnt03_Click);
            // 
            // sidebnt03
            // 
            this.sidebnt03.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebnt03.Location = new System.Drawing.Point(10, 0);
            this.sidebnt03.Name = "sidebnt03";
            this.sidebnt03.Size = new System.Drawing.Size(195, 30);
            this.sidebnt03.TabIndex = 4;
            this.sidebnt03.TabStop = false;
            this.sidebnt03.Click += new System.EventHandler(this.sidebnt03_Click);
            // 
            // clablsidebnt03
            // 
            this.clablsidebnt03.Dock = System.Windows.Forms.DockStyle.Left;
            this.clablsidebnt03.Location = new System.Drawing.Point(5, 0);
            this.clablsidebnt03.Name = "clablsidebnt03";
            this.clablsidebnt03.Size = new System.Drawing.Size(5, 30);
            this.clablsidebnt03.TabIndex = 3;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel15.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel15.Location = new System.Drawing.Point(0, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(5, 30);
            this.panel15.TabIndex = 0;
            // 
            // btbase2
            // 
            this.btbase2.Controls.Add(this.lablsidebnt02);
            this.btbase2.Controls.Add(this.sidebnt02);
            this.btbase2.Controls.Add(this.clablsidebnt02);
            this.btbase2.Controls.Add(this.panel13);
            this.btbase2.Dock = System.Windows.Forms.DockStyle.Top;
            this.btbase2.Location = new System.Drawing.Point(15, 30);
            this.btbase2.Name = "btbase2";
            this.btbase2.Size = new System.Drawing.Size(221, 30);
            this.btbase2.TabIndex = 2;
            // 
            // lablsidebnt02
            // 
            this.lablsidebnt02.AutoSize = true;
            this.lablsidebnt02.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lablsidebnt02.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lablsidebnt02.Location = new System.Drawing.Point(19, 10);
            this.lablsidebnt02.Name = "lablsidebnt02";
            this.lablsidebnt02.Size = new System.Drawing.Size(87, 11);
            this.lablsidebnt02.TabIndex = 18;
            this.lablsidebnt02.Text = "STOCK DETAIL";
            this.lablsidebnt02.Click += new System.EventHandler(this.lablsidebnt02_Click);
            // 
            // sidebnt02
            // 
            this.sidebnt02.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebnt02.Location = new System.Drawing.Point(10, 0);
            this.sidebnt02.Name = "sidebnt02";
            this.sidebnt02.Size = new System.Drawing.Size(195, 30);
            this.sidebnt02.TabIndex = 3;
            this.sidebnt02.TabStop = false;
            this.sidebnt02.Click += new System.EventHandler(this.sidebnt02_Click);
            // 
            // clablsidebnt02
            // 
            this.clablsidebnt02.Dock = System.Windows.Forms.DockStyle.Left;
            this.clablsidebnt02.Location = new System.Drawing.Point(5, 0);
            this.clablsidebnt02.Name = "clablsidebnt02";
            this.clablsidebnt02.Size = new System.Drawing.Size(5, 30);
            this.clablsidebnt02.TabIndex = 2;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel13.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel13.Location = new System.Drawing.Point(0, 0);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(5, 30);
            this.panel13.TabIndex = 0;
            // 
            // btbase1
            // 
            this.btbase1.Controls.Add(this.lablsidebnt01);
            this.btbase1.Controls.Add(this.label5);
            this.btbase1.Controls.Add(this.sidebnt01);
            this.btbase1.Controls.Add(this.clablsidebnt01);
            this.btbase1.Controls.Add(this.panel11);
            this.btbase1.Dock = System.Windows.Forms.DockStyle.Top;
            this.btbase1.Location = new System.Drawing.Point(15, 0);
            this.btbase1.Name = "btbase1";
            this.btbase1.Size = new System.Drawing.Size(221, 30);
            this.btbase1.TabIndex = 1;
            // 
            // lablsidebnt01
            // 
            this.lablsidebnt01.AutoSize = true;
            this.lablsidebnt01.Font = new System.Drawing.Font("굴림", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lablsidebnt01.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.lablsidebnt01.Location = new System.Drawing.Point(19, 10);
            this.lablsidebnt01.Name = "lablsidebnt01";
            this.lablsidebnt01.Size = new System.Drawing.Size(68, 11);
            this.lablsidebnt01.TabIndex = 17;
            this.lablsidebnt01.Text = "OVERVIEW";
            this.lablsidebnt01.Click += new System.EventHandler(this.lablsidebnt01_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "label5";
            // 
            // sidebnt01
            // 
            this.sidebnt01.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidebnt01.Location = new System.Drawing.Point(10, 0);
            this.sidebnt01.Name = "sidebnt01";
            this.sidebnt01.Size = new System.Drawing.Size(195, 30);
            this.sidebnt01.TabIndex = 3;
            this.sidebnt01.TabStop = false;
            this.sidebnt01.Click += new System.EventHandler(this.sidebnt01_Click);
            // 
            // clablsidebnt01
            // 
            this.clablsidebnt01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.clablsidebnt01.Dock = System.Windows.Forms.DockStyle.Left;
            this.clablsidebnt01.Location = new System.Drawing.Point(5, 0);
            this.clablsidebnt01.Name = "clablsidebnt01";
            this.clablsidebnt01.Size = new System.Drawing.Size(5, 30);
            this.clablsidebnt01.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel11.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(5, 30);
            this.panel11.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(15, 461);
            this.panel6.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel31);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 666);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(236, 51);
            this.panel3.TabIndex = 1;
            // 
            // panel31
            // 
            this.panel31.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel31.Location = new System.Drawing.Point(0, 0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(15, 51);
            this.panel31.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(236, 205);
            this.panel2.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label49);
            this.panel8.Controls.Add(this.regiontime);
            this.panel8.Controls.Add(this.label11);
            this.panel8.Controls.Add(this.label9);
            this.panel8.Controls.Add(this.label8);
            this.panel8.Controls.Add(this.label2);
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(15, 26);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(221, 141);
            this.panel8.TabIndex = 4;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label49.Location = new System.Drawing.Point(11, 109);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(80, 12);
            this.label49.TabIndex = 15;
            this.label49.Text = "OPEN TERMINAL";
            // 
            // regiontime
            // 
            this.regiontime.AutoSize = true;
            this.regiontime.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regiontime.ForeColor = System.Drawing.Color.White;
            this.regiontime.Location = new System.Drawing.Point(59, 74);
            this.regiontime.Name = "regiontime";
            this.regiontime.Size = new System.Drawing.Size(8, 12);
            this.regiontime.TabIndex = 14;
            this.regiontime.Text = "-";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 11F);
            this.label11.ForeColor = System.Drawing.Color.Gainsboro;
            this.label11.Location = new System.Drawing.Point(10, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(175, 17);
            this.label11.TabIndex = 12;
            this.label11.Text = "S T O C K  A N A L Y S I S";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label9.Location = new System.Drawing.Point(12, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(108, 12);
            this.label9.TabIndex = 9;
            this.label9.Text = "MADE BY DANIEL YUN";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label8.Location = new System.Drawing.Point(12, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 12);
            this.label8.TabIndex = 8;
            this.label8.Text = "REGION";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(5, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 36);
            this.label2.TabIndex = 2;
            this.label2.Text = "XTERMINAL";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel9.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(5, 141);
            this.panel9.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label1);
            this.panel7.Controls.Add(this.logoBox);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(15, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(221, 26);
            this.panel7.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(15, 205);
            this.panel5.TabIndex = 2;
            // 
            // widepanel
            // 
            this.widepanel.Controls.Add(this.chart4);
            this.widepanel.Location = new System.Drawing.Point(269, 447);
            this.widepanel.Name = "widepanel";
            this.widepanel.Size = new System.Drawing.Size(1018, 279);
            this.widepanel.TabIndex = 0;
            this.widepanel.Visible = false;
            // 
            // chart4
            // 
            this.chart4.BackColor = System.Drawing.Color.Transparent;
            this.chart4.BorderlineColor = System.Drawing.Color.Black;
            this.chart4.BorderSkin.PageColor = System.Drawing.Color.Transparent;
            chartArea4.AxisX.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea4.AxisX2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea4.AxisY.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea4.AxisY2.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea4.BackColor = System.Drawing.Color.White;
            chartArea4.BackImageAlignment = System.Windows.Forms.DataVisualization.Charting.ChartImageAlignmentStyle.Center;
            chartArea4.BorderColor = System.Drawing.Color.Transparent;
            chartArea4.BorderWidth = 0;
            chartArea4.InnerPlotPosition.Auto = false;
            chartArea4.InnerPlotPosition.Height = 100F;
            chartArea4.InnerPlotPosition.Width = 100F;
            chartArea4.Name = "ChartArea1";
            chartArea4.Position.Auto = false;
            chartArea4.Position.Height = 100F;
            chartArea4.Position.Width = 100F;
            this.chart4.ChartAreas.Add(chartArea4);
            this.chart4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart4.Location = new System.Drawing.Point(0, 0);
            this.chart4.Margin = new System.Windows.Forms.Padding(0);
            this.chart4.Name = "chart4";
            this.chart4.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series10.ChartArea = "ChartArea1";
            series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series10.LabelForeColor = System.Drawing.Color.Transparent;
            series10.Legend = "Legend1";
            series10.Name = "Series1";
            series10.YValuesPerPoint = 4;
            series11.ChartArea = "ChartArea1";
            series11.Legend = "Legend1";
            series11.Name = "Series2";
            series12.ChartArea = "ChartArea1";
            series12.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series12.Name = "Series3";
            series13.ChartArea = "ChartArea1";
            series13.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series13.Name = "Series4";
            this.chart4.Series.Add(series10);
            this.chart4.Series.Add(series11);
            this.chart4.Series.Add(series12);
            this.chart4.Series.Add(series13);
            this.chart4.Size = new System.Drawing.Size(1018, 279);
            this.chart4.TabIndex = 2;
            this.chart4.Text = "chart1";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 800);
            this.Controls.Add(this.panel_home);
            this.Controls.Add(this.panel_up);
            this.Controls.Add(this.widepanel);
            this.DisplayHeader = false;
            this.Name = "Main";
            this.Padding = new System.Windows.Forms.Padding(5, 40, 10, 10);
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Black;
            this.Text = "Form1";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_up.ResumeLayout(false);
            this.panel_up.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoBox)).EndInit();
            this.panel_home.ResumeLayout(false);
            this.panel_test.ResumeLayout(false);
            this.panel_detailView.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel58.ResumeLayout(false);
            this.panel67.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panel_chart1under.ResumeLayout(false);
            this.panel86.ResumeLayout(false);
            this.panel87.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel88.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel89.ResumeLayout(false);
            this.panel89.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel90.ResumeLayout(false);
            this.panel90.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel92.ResumeLayout(false);
            this.panel93.ResumeLayout(false);
            this.panel93.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel94.ResumeLayout(false);
            this.panel94.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel95.ResumeLayout(false);
            this.panel95.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.panel96.ResumeLayout(false);
            this.panel96.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.panel97.ResumeLayout(false);
            this.panel98.ResumeLayout(false);
            this.panel98.PerformLayout();
            this.panel99.ResumeLayout(false);
            this.panel99.PerformLayout();
            this.panel102.ResumeLayout(false);
            this.panel103.ResumeLayout(false);
            this.panel103.PerformLayout();
            this.panel104.ResumeLayout(false);
            this.panel104.PerformLayout();
            this.panel105.ResumeLayout(false);
            this.panel105.PerformLayout();
            this.panel106.ResumeLayout(false);
            this.panel106.PerformLayout();
            this.panel107.ResumeLayout(false);
            this.panel108.ResumeLayout(false);
            this.panel108.PerformLayout();
            this.panel109.ResumeLayout(false);
            this.panel109.PerformLayout();
            this.panel110.ResumeLayout(false);
            this.panel110.PerformLayout();
            this.panel111.ResumeLayout(false);
            this.panel111.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel60.ResumeLayout(false);
            this.panel70.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.panel49.ResumeLayout(false);
            this.panel49.PerformLayout();
            this.pnlbtn_CA_03.ResumeLayout(false);
            this.pnlbtn_CA_03.PerformLayout();
            this.pnlbtn_CA_04.ResumeLayout(false);
            this.pnlbtn_CA_04.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel112.ResumeLayout(false);
            this.panel112.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.panel61.ResumeLayout(false);
            this.panel68.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.panel_chart2under.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel80.ResumeLayout(false);
            this.panel81.ResumeLayout(false);
            this.panel81.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel82.ResumeLayout(false);
            this.panel82.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y05)).EndInit();
            this.panel84.ResumeLayout(false);
            this.panel84.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y06)).EndInit();
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y07)).EndInit();
            this.panel45.ResumeLayout(false);
            this.panel76.ResumeLayout(false);
            this.panel76.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y04)).EndInit();
            this.panel77.ResumeLayout(false);
            this.panel77.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y01)).EndInit();
            this.panel79.ResumeLayout(false);
            this.panel79.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y03)).EndInit();
            this.panel78.ResumeLayout(false);
            this.panel78.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_chart2_y02)).EndInit();
            this.panel40.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel73.ResumeLayout(false);
            this.panel73.PerformLayout();
            this.panel75.ResumeLayout(false);
            this.panel75.PerformLayout();
            this.panel74.ResumeLayout(false);
            this.panel74.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel46.PerformLayout();
            this.panel72.ResumeLayout(false);
            this.panel72.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.panel71.ResumeLayout(false);
            this.panel71.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel62.ResumeLayout(false);
            this.panel59.ResumeLayout(false);
            this.panel59.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel85.ResumeLayout(false);
            this.panel85.PerformLayout();
            this.panel_tmp2.ResumeLayout(false);
            this.panel_tmp2.PerformLayout();
            this.panel_tmp1.ResumeLayout(false);
            this.panel_tmp1.PerformLayout();
            this.panel_prediction.ResumeLayout(false);
            this.panel_prediction.PerformLayout();
            this.panel_tracking.ResumeLayout(false);
            this.panel_tracking.PerformLayout();
            this.panel_list.ResumeLayout(false);
            this.panel_list.PerformLayout();
            this.panel_stock.ResumeLayout(false);
            this.panel_stock.PerformLayout();
            this.panel_overview.ResumeLayout(false);
            this.panel_overview.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel_searchbox.ResumeLayout(false);
            this.panel_searchbox.PerformLayout();
            this.panel_search.ResumeLayout(false);
            this.panel_search.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel_stckName.ResumeLayout(false);
            this.panel_stckName.PerformLayout();
            this.panel_upStockName.ResumeLayout(false);
            this.panel_upStockName.PerformLayout();
            this.panel_side.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel55.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel52.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.panel32.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.btbase9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.btbase8.ResumeLayout(false);
            this.btbase8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt08)).EndInit();
            this.btbase7.ResumeLayout(false);
            this.btbase7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt07)).EndInit();
            this.btbase6.ResumeLayout(false);
            this.btbase6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt06)).EndInit();
            this.btbase5.ResumeLayout(false);
            this.btbase5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt05)).EndInit();
            this.btbase4.ResumeLayout(false);
            this.btbase4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt04)).EndInit();
            this.btbase3.ResumeLayout(false);
            this.btbase3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt03)).EndInit();
            this.btbase2.ResumeLayout(false);
            this.btbase2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt02)).EndInit();
            this.btbase1.ResumeLayout(false);
            this.btbase1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sidebnt01)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.widepanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_up;
        private System.Windows.Forms.Panel panel_home;
        private System.Windows.Forms.Panel panel_logo;
        private System.Windows.Forms.PictureBox logoBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_side;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel btbase1;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel btbase7;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel btbase6;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel btbase5;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel btbase4;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel btbase3;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel btbase2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel btbase9;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel btbase8;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label worldtime;
        private System.Windows.Forms.Label regiontime;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Panel panel_search;
        private System.Windows.Forms.TextBox tb_searchbox;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel_stckName;
        private System.Windows.Forms.Panel panel_upStockName;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel_detailView;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label lb_upstockName;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel_searchbox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.PictureBox sidebnt08;
        private System.Windows.Forms.Panel clablsidebnt08;
        private System.Windows.Forms.PictureBox sidebnt07;
        private System.Windows.Forms.Panel clablsidebnt07;
        private System.Windows.Forms.PictureBox sidebnt06;
        private System.Windows.Forms.Panel clablsidebnt06;
        private System.Windows.Forms.PictureBox sidebnt05;
        private System.Windows.Forms.Panel clablsidebnt05;
        private System.Windows.Forms.PictureBox sidebnt04;
        private System.Windows.Forms.Panel clablsidebnt04;
        private System.Windows.Forms.PictureBox sidebnt03;
        private System.Windows.Forms.Panel clablsidebnt03;
        private System.Windows.Forms.PictureBox sidebnt02;
        private System.Windows.Forms.Panel clablsidebnt02;
        private System.Windows.Forms.PictureBox sidebnt01;
        private System.Windows.Forms.Panel clablsidebnt01;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label lb_stockName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel62;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Panel panel64;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel69;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.Label lablsidebnt01;
        private System.Windows.Forms.Label lablsidebnt08;
        private System.Windows.Forms.Label lablsidebnt07;
        private System.Windows.Forms.Label lablsidebnt06;
        private System.Windows.Forms.Label lablsidebnt05;
        private System.Windows.Forms.Label lablsidebnt04;
        private System.Windows.Forms.Label lablsidebnt03;
        private System.Windows.Forms.Label lablsidebnt02;
        private System.Windows.Forms.Panel panel_tmp2;
        private System.Windows.Forms.Panel panel_tmp1;
        private System.Windows.Forms.Panel panel_tracking;
        private System.Windows.Forms.Panel panel_stock;
        private System.Windows.Forms.Panel panel_list;
        private System.Windows.Forms.Panel panel_prediction;
        private System.Windows.Forms.Panel panel_test;
        private System.Windows.Forms.Panel panel_overview;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel80;
        private System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.Panel panel82;
        private System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Panel panel83;
        public System.Windows.Forms.Label lbmin_lp;
        public System.Windows.Forms.Label lbmin_op;
        public System.Windows.Forms.Label lbmin_cp;
        public System.Windows.Forms.Label lbmin_hp;
        public System.Windows.Forms.Label lbmax_lp;
        public System.Windows.Forms.Label lbmax_op;
        public System.Windows.Forms.Label lbmax_hp;
        public System.Windows.Forms.Label lbmax_cp;
        public System.Windows.Forms.PictureBox pictureBox6;
        public System.Windows.Forms.PictureBox btn_chart2_y05;
        public System.Windows.Forms.PictureBox btn_chart2_y06;
        public System.Windows.Forms.PictureBox btn_chart2_y07;
        public System.Windows.Forms.PictureBox btn_chart2_y04;
        public System.Windows.Forms.PictureBox btn_chart2_y01;
        public System.Windows.Forms.PictureBox btn_chart2_y03;
        public System.Windows.Forms.PictureBox btn_chart2_y02;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        public System.Windows.Forms.Panel panel_chart2under;
        public System.Windows.Forms.Label OnBtn01;
        public System.Windows.Forms.Label OnBtn04;
        public System.Windows.Forms.Label OnBtn03;
        public System.Windows.Forms.Label OnBtn02;
        public System.Windows.Forms.Label OnYearBtn04;
        public System.Windows.Forms.Label OnYearBtn01;
        public System.Windows.Forms.Label OnYearBtn02;
        public System.Windows.Forms.Label OnYearBtn03;
        private System.Windows.Forms.Panel pnlbtn_CA_03;
        private System.Windows.Forms.Panel pnlbtn_CA_04;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        public System.Windows.Forms.Panel panel_chart1under;
        private System.Windows.Forms.Panel panel86;
        private System.Windows.Forms.Panel panel87;
        private System.Windows.Forms.Panel panel88;
        public System.Windows.Forms.Label chrt1md4;
        public System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel89;
        public System.Windows.Forms.Label chrt1md1;
        public System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel90;
        public System.Windows.Forms.Label chrt1md2;
        public System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel91;
        public System.Windows.Forms.Label chrt1md3;
        public System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel92;
        private System.Windows.Forms.Panel panel93;
        public System.Windows.Forms.Label label30;
        public System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel panel94;
        public System.Windows.Forms.Label label31;
        public System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Panel panel95;
        public System.Windows.Forms.Label label32;
        public System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Panel panel96;
        public System.Windows.Forms.Label label33;
        public System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Panel panel97;
        private System.Windows.Forms.Panel panel98;
        public System.Windows.Forms.Label ch4_ltime;
        private System.Windows.Forms.Panel panel99;
        public System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel102;
        private System.Windows.Forms.Panel panel103;
        public System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel104;
        public System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel105;
        public System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel panel106;
        public System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel panel107;
        private System.Windows.Forms.Panel panel108;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel109;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel panel110;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panel111;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel85;
        private System.Windows.Forms.Label btn_chart2;
        private System.Windows.Forms.Panel panel112;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Panel widepanel;
        public System.Windows.Forms.DataVisualization.Charting.Chart chart4;
    }
}

