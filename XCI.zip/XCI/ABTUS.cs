﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XCI
{
    public partial class ABTUS : MetroFramework.Forms.MetroForm
    {
        public ABTUS()
        {
            InitializeComponent();
        }

        private void ABTUS_Load(object sender, EventArgs e)
        {

        }
    }
}
